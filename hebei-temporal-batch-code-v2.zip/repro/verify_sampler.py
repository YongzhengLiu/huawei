"""Independent list-based sampler reconstruction; no training-side helper calls."""
import numpy as np
import hashlib,json

def reconstruct(native,chronological,batch=256):
    p=[int(x) for x in native];chron=[int(x) for x in chronological];n=len(p)
    assert sorted(p)==list(range(n)) and sorted(chron)==list(range(n))
    rank={v:i for i,v in enumerate(p)};priority=[];seen=set()
    for row in p:
        b=row%batch
        if b not in seen:seen.add(b);priority.append(b)
    large=set(priority[:n%batch]);groups=[];cursor=0
    for b in range(batch):
        size=n//batch+(b in large);groups.append(sorted(chron[cursor:cursor+size],key=rank.__getitem__));cursor+=size
    assert cursor==n
    result=[]
    for j in range((n+batch-1)//batch):
        rows=[g[j] for g in groups if j<len(g)];result.extend(sorted(rows,key=rank.__getitem__))
    return np.asarray(result,dtype=np.int64)

def verify_saved(path):
    with np.load(path,allow_pickle=False) as z:
        native=z['native'];issues=z['fit_issues'];expected=z['candidate_SHA'];sizes=z['batch_sizes']
    assert native.shape==(96,40522) and issues.shape==(40522,) and len(np.unique(issues))==40522
    chronology=np.argsort(issues,kind='stable');assert sizes.tolist()==[256]*158+[74]
    hashes=[]
    for epoch in range(96):
        result=reconstruct(native[epoch],chronology);h=hashlib.sha256(result.astype('<i8').tobytes()).hexdigest();assert h==str(expected[epoch]),epoch;hashes.append(h)
    return dict(all96_full40522_permutations_independently_reconstructed=True,batch_sizes=sizes.tolist(),candidate_order_SHA=hashes,fit_only_issue_chronology=True,querytruth_read=False)

def verify_epoch_hashes(issues,seed,expected):
    chronology=np.argsort(issues,kind='stable');rng=np.random.default_rng(seed+1000)
    assert len(expected)==96
    for epoch,h in enumerate(expected):
        p=rng.permutation(len(issues));x=reconstruct(p,chronology)
        assert hashlib.sha256(x.astype('<i8').tobytes()).hexdigest()==h,epoch
    return True
