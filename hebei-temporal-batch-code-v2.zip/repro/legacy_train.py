"""Original Branch class, with unrelated historical training entrypoints excluded."""
import torch
from torch import nn
class Branch(nn.Module):
    def __init__(self, input_dim, hidden, output_dim, dropout):
        super().__init__()
        layers = []
        for width in hidden:
            layers.extend([nn.Linear(input_dim, width), nn.LayerNorm(width), nn.GELU(), nn.Dropout(dropout)])
            input_dim = width
        layers.append(nn.Linear(input_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)
