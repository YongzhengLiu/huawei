"""Dataset, foundation-model and feature/corrector extension interfaces.

This layer never changes the immutable Hebei reproduction preset.
"""
