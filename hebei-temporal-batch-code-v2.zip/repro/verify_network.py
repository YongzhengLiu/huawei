"""Independent NumPy evaluation of frozen WPAIR heads before scoring labels."""
import json,hashlib,math,csv,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def npz(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def gelu(x):return .5*x*(1+np.vectorize(math.erf,otypes=[float])(x/math.sqrt(2)))
def linear(x,w,k):return x@w[k+'.weight'].astype(float).T+w[k+'.bias']
def hidden(x,w,name):
    for index in (0,4,8):
        x=linear(x,w,f'{name}.net.{index}')
        x=(x-x.mean(1,keepdims=True))/np.sqrt(x.var(1,keepdims=True)+1e-5)
        x=x*w[f'{name}.net.{index+1}.weight']+w[f'{name}.net.{index+1}.bias'];x=gelu(x)
    return x
def decode(base,level,shape):
    base=base.astype(float);level=np.clip(level.astype(float).reshape(-1,1),-2,2)
    shape=shape.astype(float);shape=np.clip(shape-shape.mean(1,keepdims=True),-2,2)
    c=base*np.exp(shape);return base.mean(1,keepdims=True)*np.exp(level)*c/c.mean(1,keepdims=True)
def verify(folder):
    marker=json.loads((folder/'COMPLETE.json').read_text());assert (folder/'COMPLETE').read_bytes()==b'complete\n'
    for n,h in marker['files_sha256'].items():
        assert Path(n).name==n
        if not (folder/n).exists():assert n in ('checkpoint.pt','native_R1_weather.npz'),n
        else:assert sha(folder/n)==h,n
    w=npz(folder/'weights.npz');d=npz(folder/'replay_inputs.npz');p=npz(folder/'issued.npz');x=d['x'].astype(float)
    z=hidden(x,w,'level');c=gelu(linear(x[:,w['cond_idx']],w,'condition.0'));c=linear(c,w,'condition.2')
    gamma,beta=np.split(c,2,axis=1);last=linear((1+.1*np.tanh(gamma))*z+.1*np.tanh(beta),w,'level.net.12')
    assert last.shape[1] in (1,2)
    level=last if last.shape[1]==1 else (last[:,0:1]-last[:,1:2]-d['level_mean'])/d['level_std']
    shape=linear(hidden(x[:,:2813],w,'shape'),w,'shape.net.12')
    tol=128*np.finfo(np.float32).eps
    for value,name in ((level,'level'),(shape,'shape')):
        ref=(p[name].astype(float)-d[name+'_mean'])/d[name+'_std']
        np.testing.assert_allclose(value,ref,rtol=tol,atol=tol)
    physical=decode(d['base'],level*d['level_std']+d['level_mean'],shape*d['shape_std']+d['shape_mean'])
    np.testing.assert_allclose(physical,p['prediction160'],rtol=3e-6,atol=.01)
    direct=decode(d['base'],p['level'],p['shape']);decoder_error=float(np.max(np.abs(direct-p['prediction160'])));decoder_bound=512*np.finfo(np.float64).eps*max(1.,float(np.max(np.abs(p['prediction160']))));assert decoder_error<=decoder_bound
    assert p['prediction160'].shape==(102,160)
    np.testing.assert_array_equal(p['target_start_time'].astype('datetime64[D]'),np.arange(np.datetime64('2026-01-01'),np.datetime64('2026-04-13')))
    return dict(files_SHA_verified=True,independent_numpy_full_network_max_abs=float(np.max(np.abs(physical-p['prediction160']))),independent_decoder_max_abs=decoder_error,analytical_float64_decoder_bound=decoder_bound,standardized_tolerance=tol,all102x160_verified=True,query_truth_opened=False)

def main(folder):
    folder=Path(folder);r=verify(folder)
    target=ROOT/'report'/('PREFLIGHT_NETWORK_VERIFY.json' if folder.name=='preflight' else folder.name.upper()+'_NETWORK_VERIFY.json')
    with target.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
    print(json.dumps(r))
if __name__=='__main__':main(sys.argv[1])
