"""Original model/predict/decoder functions; only file roots are relocated."""
from pathlib import Path
import hashlib,json,numpy as np,torch
from recipes import Model,resolve,losses
from schema import get_schema
from group_weights import PhaseYearWeights
from paths import CFG,UP
OLD=Path(CFG['prior_root'])
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()

def model(seed,cond,film):
    cfg=dict(CFG,seed=seed);m=Model(2573,cond,cfg,resolve('D2'))
    # Retain parameter names/shapes and constructor RNG of the original model.
    if film=='off':m.scale=0.0
    elif film=='constant':
        def zeros_hook(module,args):return (torch.zeros_like(args[0]),)
        m.condition.register_forward_pre_hook(zeros_hook)
    return m

def files(year):
    old=OLD/f'data/fold_{year}'
    result=OLD/f'results/{"test" if year==2026 else "development"}/year_{year}/D2/seed_42'
    return old,result

def predict(m,x,norm):
    m.eval();ls=[];ss=[]
    with torch.inference_mode():
        for i in range(0,len(x),256):
            l,s=m(torch.from_numpy(np.ascontiguousarray(x[i:i+256])));ls.append(l.numpy());ss.append(s.numpy())
    return np.concatenate(ls)*norm['level_std']+norm['level_mean'],np.concatenate(ss)*norm['shape_std']+norm['shape_mean']

def reconstruct(base,level,shape):
    b=np.asarray(base,np.float64)
    ell=np.clip(np.asarray(level,np.float64).reshape(-1,1),-2,2)
    sh=np.asarray(shape,np.float64);sh=sh-sh.mean(1,keepdims=True);sh=np.clip(sh,-2,2)
    curve=b*np.exp(sh)
    return b.mean(1,keepdims=True)*np.exp(ell)*curve/curve.mean(1,keepdims=True)
