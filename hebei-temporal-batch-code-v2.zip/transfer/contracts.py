from dataclasses import dataclass
from typing import Protocol, Mapping, Any, Optional, runtime_checkable
import numpy as np

@dataclass(frozen=True)
class WindowSpec:
    frequency_minutes:int=15
    history_length:int=672
    horizon:int=160
    score_start:int=64
    score_length:int=96
    timezone:str='Asia/Shanghai'
    def validate(self):
        assert self.frequency_minutes>0 and self.history_length>0 and self.horizon>0
        assert self.score_start>=0 and self.score_length>0 and self.score_start+self.score_length<=self.horizon

@dataclass
class WindowBatch:
    issue_time:np.ndarray
    target_start_time:np.ndarray
    past_target:np.ndarray
    past_last_time:np.ndarray
    future_known_covariates:Optional[np.ndarray]=None
    future_covariate_available_at:Optional[np.ndarray]=None
    covariate_names:tuple=()
    perfect_weather:bool=False
    def validate(self,spec:WindowSpec,allow_perfect_weather:bool=False):
        spec.validate();n=len(self.issue_time)
        issue=np.asarray(self.issue_time,dtype='datetime64[m]')
        assert issue.shape==(n,) and len(np.unique(issue))==n and not np.isnat(issue).any()
        assert self.past_target.shape==(n,spec.history_length) and np.isfinite(self.past_target).all() and (self.past_target>0).all()
        assert np.asarray(self.past_last_time,dtype='datetime64[m]').shape==(n,)
        assert np.all(np.asarray(self.past_last_time,dtype='datetime64[m]')<issue),'Future load in history'
        np.testing.assert_array_equal(np.asarray(self.target_start_time,dtype='datetime64[m]'),issue+np.timedelta64(spec.score_start*spec.frequency_minutes,'m'))
        if self.future_known_covariates is not None:
            z=self.future_known_covariates
            assert z.ndim==3 and z.shape[:2]==(n,spec.horizon) and z.shape[2]==len(self.covariate_names) and np.isfinite(z).all()
            if self.perfect_weather:assert allow_perfect_weather,'Perfect-weather access must be explicitly declared'
            else:
                assert self.future_covariate_available_at is not None,'Declare each future covariate availability time'
                a=np.asarray(self.future_covariate_available_at,dtype='datetime64[m]')
                assert a.shape in ((n,spec.horizon),(n,spec.horizon,z.shape[2]))
                boundary=issue.reshape((n,)+(1,)*(a.ndim-1))
                assert not np.isnat(a).any() and np.all(a<=boundary),'Future covariate was unavailable at issue'
        return self

@dataclass
class FitBatch:
    windows:WindowBatch
    future_target:np.ndarray
    def validate(self,spec:WindowSpec,first_query_issue):
        self.windows.validate(spec)
        y=self.future_target;assert y.shape==(len(self.windows.issue_time),spec.horizon) and np.isfinite(y).all() and (y>0).all()
        label_end=np.asarray(self.windows.issue_time,dtype='datetime64[m]')+np.timedelta64((spec.horizon-1)*spec.frequency_minutes,'m')
        assert np.all(label_end<np.datetime64(first_query_issue,'m')),'Fit labels have not matured before first query'
        return self

@dataclass
class ForecastBatch:
    point:np.ndarray
    scene:Optional[np.ndarray]=None
    quantiles:Optional[Mapping[float,np.ndarray]]=None
    metadata:Optional[Mapping[str,Any]]=None
    def validate(self,n:int,spec:WindowSpec):
        assert self.point.shape==(n,spec.horizon) and np.isfinite(self.point).all() and (self.point>0).all()
        if self.scene is not None:assert self.scene.ndim==2 and self.scene.shape[0]==n and np.isfinite(self.scene).all()
        if self.quantiles:
            for q,x in self.quantiles.items():assert 0<float(q)<1 and x.shape==self.point.shape and np.isfinite(x).all()
        return self

@runtime_checkable
class DatasetProvider(Protocol):
    def load_fit(self)->FitBatch:...
    def load_query(self)->WindowBatch:...

@runtime_checkable
class ForecastBackend(Protocol):
    def predict(self,batch:WindowBatch,spec:WindowSpec)->ForecastBatch:...
    def fingerprint(self)->Mapping[str,Any]:...

@runtime_checkable
class FeatureBuilder(Protocol):
    """Fit normalizers exclusively on FitBatch; query has no target field."""
    def fit(self,fit:FitBatch,base:ForecastBatch)->None:...
    def transform(self,windows:WindowBatch,base:ForecastBatch)->Mapping[str,np.ndarray]:...
    def state_dict(self)->Mapping[str,Any]:...

@runtime_checkable
class CorrectorRunner(Protocol):
    """Plugin controls dimensions; it must preserve the temporal sampler if claimed."""
    def fit(self,features:Mapping[str,np.ndarray],targets:FitBatch,config:Mapping[str,Any])->None:...
    def predict(self,features:Mapping[str,np.ndarray],base:ForecastBatch)->np.ndarray:...
