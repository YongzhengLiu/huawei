"""Reuse the exact sampler operation with arbitrary dataset size and batch size."""
from pathlib import Path
import importlib.util
import numpy as np
p=Path(__file__).resolve().parents[1]/'repro/sampler.py'
spec=importlib.util.spec_from_file_location('_frozen_temporal_order',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

def temporal_order(issue_time,seed,epoch,batch_size=256):
    stamps=np.asarray(issue_time,dtype='datetime64[m]');n=len(stamps)
    assert stamps.ndim==1 and len(np.unique(stamps))==n and n>=batch_size and epoch>=1
    rng=np.random.default_rng(seed+1000)
    for _ in range(epoch):native=rng.permutation(n)
    out=module.order(native,np.argsort(stamps,kind='stable'),enabled=True,batch=batch_size)
    np.testing.assert_array_equal(np.sort(out),np.arange(n))
    return out
