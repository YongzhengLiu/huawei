"""Contract and leakage tests only; no real model fit or quality claims."""
from pathlib import Path
import sys,tempfile,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from transfer.contracts import WindowSpec,WindowBatch,FitBatch,ForecastBatch
from transfer.backends import LastValueBackend,ExternalNpzBackend
from transfer.datasets import NpzWindowDataset
from transfer.pipeline import prepare_for_transfer,cache_fingerprint
from transfer.temporal import temporal_order

def windows(issues,spec,offset=0):
    issue=np.array(issues,dtype='datetime64[m]');n=len(issue)
    return WindowBatch(issue,issue+np.timedelta64(spec.score_start*spec.frequency_minutes,'m'),np.arange(n*spec.history_length,dtype=float).reshape(n,spec.history_length)+10+offset,issue-np.timedelta64(spec.frequency_minutes,'m'))
class Builder:
    def fit(self,fit,base):self.mean=float(fit.windows.past_target.mean());self.calls=1
    def transform(self,w,base):return {'x':np.column_stack((w.past_target.mean(1)-self.mean,base.point.mean(1)))}
    def state_dict(self):return {'fit_only_mean':self.mean,'fit_calls':self.calls}
def rejected(fn):
    try:fn()
    except (AssertionError,ValueError):return
    raise AssertionError('Expected contract rejection')

def test_all():
    spec=WindowSpec(frequency_minutes=30,history_length=4,horizon=6,score_start=2,score_length=4,timezone='UTC')
    fit=FitBatch(windows(['2025-01-01T08:00','2025-01-02T08:00'],spec),np.ones((2,6))*20)
    query=windows(['2025-01-05T08:00'],spec)
    class Dataset:
        def load_fit(self):return fit
        def load_query(self):return query
    a=prepare_for_transfer(Dataset(),LastValueBackend(),Builder(),spec)
    query.past_target+=1000
    b=prepare_for_transfer(Dataset(),LastValueBackend(),Builder(),spec)
    assert a['feature_state']==b['feature_state'] and not np.array_equal(a['query_features']['x'],b['query_features']['x'])
    bad=windows(['2025-01-05T08:00'],spec);bad.past_last_time=bad.issue_time.copy();rejected(lambda:bad.validate(spec))
    late=FitBatch(windows(['2025-01-05T07:00'],spec),np.ones((1,6)));rejected(lambda:late.validate(spec,query.issue_time.min()))
    bad=windows(['2025-01-05T08:00'],spec);bad.future_known_covariates=np.ones((1,6,1));bad.covariate_names=('temperature',);bad.future_covariate_available_at=np.full((1,6),np.datetime64('2025-01-05T09:00'));rejected(lambda:bad.validate(spec))
    bad.perfect_weather=True;rejected(lambda:bad.validate(spec));bad.validate(spec,allow_perfect_weather=True)
    with tempfile.TemporaryDirectory() as tmp:
        p=Path(tmp)/'other_model.npz';np.savez(p,issue_time=query.issue_time,point=np.full((1,6),123.),scene=np.ones((1,7)))
        ext=ExternalNpzBackend(p);f=ext.predict(query,spec);assert f.point.shape==(1,6) and f.scene.shape==(1,7)
        assert cache_fingerprint({'dataset':'a'},ext.fingerprint())!=cache_fingerprint({'dataset':'a'},LastValueBackend().fingerprint())
        p2=Path(tmp)/'query_bad.npz';np.savez(p2,issue_time=query.issue_time,future_target=np.ones((1,6)));rejected(lambda:NpzWindowDataset(p2,p2).load_query())
    issues=np.datetime64('2020-01-01')+np.arange(103)*np.timedelta64(30,'m');order=temporal_order(issues,42,1,batch_size=8);assert len(order)==103 and len(np.unique(order))==103
    ForecastBatch(np.ones((1,6)),scene=np.ones((1,13))).validate(1,spec)
    print(json.dumps(dict(passed=True,different_history_horizon_frequency_and_scene_dimensions=True,fit_only_normalizer_invariant_to_query_values=True,future_load_and_unavailable_weather_rejected=True,query_truth_separate=True,foundation_model_replacement_changes_cache_key=True,original_temporal_sampler_arbitrary_rows=True,no_real_fit=True)))
if __name__=='__main__':test_all()
