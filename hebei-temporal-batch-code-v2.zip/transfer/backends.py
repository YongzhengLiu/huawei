from pathlib import Path
import hashlib
import numpy as np
from .contracts import ForecastBatch

class ChronosBoltBackend:
    """Chronos adapter only. Other foundation models implement the same protocol.

No assumption that another model exposes a 768-dimensional scene embedding.
The standard adapter returns point/quantiles; a custom adapter may return scene.
"""
    def __init__(self,model_path,runtime_path=None,device='cpu',point_quantile=0.5):
        import sys
        if runtime_path:sys.path.insert(0,str(Path(runtime_path).resolve()))
        import torch
        from chronos import BaseChronosPipeline
        self.torch=torch;self.path=Path(model_path).resolve();self.q=float(point_quantile)
        self.pipeline=BaseChronosPipeline.from_pretrained(str(self.path),device_map=device,torch_dtype=torch.float32,local_files_only=True)
        self.pipeline.model.eval()
    def predict(self,batch,spec):
        x=self.torch.from_numpy(np.asarray(batch.past_target,dtype=np.float32).copy())
        with self.torch.inference_mode():z=self.pipeline.predict(x,prediction_length=spec.horizon).cpu().numpy()
        qs=list(self.pipeline.model.config.chronos_config['quantiles']);assert z.shape==(len(x),len(qs),spec.horizon) and self.q in qs
        return ForecastBatch(z[:,qs.index(self.q),:],quantiles={float(q):z[:,i,:] for i,q in enumerate(qs)},metadata=dict(backend='ChronosBoltBackend',future_covariates_used_by_FM=False)).validate(len(x),spec)
    def fingerprint(self):
        weights=self.path/'model.safetensors';h=hashlib.sha256()
        with weights.open('rb') as f:
            for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
        return dict(backend='ChronosBoltBackend',weights_SHA256=h.hexdigest(),point_quantile=self.q)

class ExternalNpzBackend:
    """Any foundation model can supply issue_time, point[N,H], optional scene[N,D]."""
    def __init__(self,path):self.path=Path(path)
    def predict(self,batch,spec):
        with np.load(self.path,allow_pickle=False) as z:
            assert not ({'truth','truth96','truth160','future_target'}&set(z.files))
            stamps=z['issue_time'].astype('datetime64[m]');order=np.argsort(stamps);sorted_stamps=stamps[order]
            assert len(np.unique(stamps))==len(stamps)
            query=np.asarray(batch.issue_time,dtype='datetime64[m]');ix=np.searchsorted(sorted_stamps,query);assert (ix<len(stamps)).all();np.testing.assert_array_equal(sorted_stamps[ix],query);ix=order[ix]
            return ForecastBatch(z['point'][ix],z['scene'][ix] if 'scene' in z.files else None,metadata=dict(backend='ExternalNpzBackend')).validate(len(ix),spec)
    def fingerprint(self):
        h=hashlib.sha256()
        with self.path.open('rb') as f:
            for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
        return dict(backend='ExternalNpzBackend',file_SHA256=h.hexdigest())

class LastValueBackend:
    """Contract-test backend only, not a claimed forecasting result."""
    def predict(self,batch,spec):return ForecastBatch(np.repeat(batch.past_target[:,-1:],spec.horizon,axis=1),metadata={'contract_test_only':True}).validate(len(batch.issue_time),spec)
    def fingerprint(self):return dict(backend='LastValueBackend',contract_test_only=True)
