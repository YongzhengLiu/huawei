import numpy as np,torch
import engine as r
import assembly as first
CANDIDATES=('DROP_AB','WPAIR_DROPAB')

def dropped():
    blocks=r.get_schema()['blocks'];cols=[]
    for name in ('city_dispersion_full40_summary','h3_holiday_category'):
        b=blocks[name];cols+=list(range(b['start'],b['end_exclusive']))
    assert len(cols)==len(set(cols))==441 and max(cols)<2573
    return sorted(cols)

def weather_kind(cid):
    assert cid in CANDIDATES+('ZERO',)
    return 'WPAIR' if cid=='WPAIR_DROPAB' else 'ZERO'

def features(year,cid,xf,xq,wc,q):
    if cid!='ZERO':
        xf[:,dropped()]=0.;xq[:,dropped()]=0.
    return first.features(year,weather_kind(cid),xf,xq,wc,q)

def model(seed,cond,cid,year=None):return first.model(seed,cond,weather_kind(cid))

def mask_blocks(cid):return first.mask_blocks(weather_kind(cid))
