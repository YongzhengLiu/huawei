"""Portable file roots and runtime checks; all data/model arithmetic below is original."""
import sys,time,os,json,hashlib,random,math,subprocess,resource
from pathlib import Path
sys.dont_write_bytecode=True
import numpy as np,torch
import legacy_interface as old
from paths import PACKAGE,SNAPSHOT
START=time.perf_counter()
ROOT=Path(os.environ['HEBEI_OUTPUT']).resolve()
MAIN=SNAPSHOT/'hebei_day_ahead_fm_20261021'
HOME=SNAPSHOT
LEGACY=SNAPSHOT/'hebei_r1_goal98_20261013'
ID='WPAIR_FULL_COVERAGE_TEMPORAL_STRATIFIED_BATCH_R1_20261029'
LIMIT=437.9050777773062
def locked():
 assert sys.version_info[:2]==(3,11),'Use the pinned Python3.11 environment'
 assert torch.__version__=='2.0.1+cu118' and np.__version__=='1.24.1','Use requirements-training.txt; other versions are not the recorded training environment'
 torch.set_num_threads(8);torch.use_deterministic_algorithms(True)
 from integrity import verify_payload
 result=verify_payload()
 return result,dict(python=sys.version,torch=str(torch.__version__),numpy=np.__version__,threads=8,GPU_hours=0,portable_retraining=True)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def write(p,v):
    p=Path(p);assert ROOT in p.resolve().parents and not p.exists(),str(p)
    p.parent.mkdir(parents=True,exist_ok=True)
    encoded=json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False,default=lambda a:a.item() if isinstance(a,np.generic) else (_ for _ in ()).throw(TypeError(type(a).__name__)))+'\n'
    with p.open('x') as f:f.write(encoded)

def npz(p,keys=None):
    p=Path(p).resolve();assert HOME in p.parents
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in (z.files if keys is None else keys)}

def finish(out,extra=None):
    assert not any(out.glob('FAILED*'))
    write(out/'COMPLETE.json',dict(identity=ID,files_sha256={p.name:sha(p) for p in out.iterdir() if p.is_file()},**(extra or {})))
    (out/'COMPLETE').open('xb').write(b'complete\n')

def complete(out):
    assert (out/'COMPLETE').read_bytes()==b'complete\n' and not any(out.glob('FAILED*'))
    c=json.loads((out/'COMPLETE.json').read_text());assert c['identity']==ID
    for n,h in c['files_sha256'].items():assert Path(n).name==n and sha(out/n)==h,n
    return c

def load():
    t=time.perf_counter();fold,clock=old.r.files(2026)
    xf=np.load(fold/'xfit.npy',allow_pickle=False).copy();raw=np.load(fold/'xquery.npy',allow_pickle=False).copy()
    norm=npz(fold/'normalization.npz');meta=json.loads((fold/'metadata.json').read_text())
    wc=npz(clock/'clock_weights.npz',('issue_time','weights','shape_weights'))
    q=npz(old.r.UP/'data/fold_2026/query.npz',('issue_time','target_start_time','base160'))
    level=np.load(fold/'level.npy',allow_pickle=False);shape=np.load(fold/'shape.npy',allow_pickle=False)
    issue=np.load(fold/'issuefit.npy',allow_pickle=False)
    assert xf.shape==(40522,2585) and raw.shape==(102,2585) and shape.shape==(40522,160)
    np.testing.assert_array_equal(issue,wc['issue_time'])
    assert (issue+np.timedelta64(159*15,'m')<q['issue_time'].min()).all()
    assert q['issue_time'].min()==np.datetime64('2025-12-31T08:00')
    np.testing.assert_array_equal(q['target_start_time'],q['issue_time']+np.timedelta64(16,'h'))
    np.testing.assert_array_equal(q['target_start_time'].astype('datetime64[D]'),np.arange(np.datetime64('2026-01-01'),np.datetime64('2026-04-13')))
    assert (q['issue_time'].astype('datetime64[m]').astype(int)%1440==480).all()
    weather=LEGACY/'data/year_2026/WPAIR';assert all((weather/n).is_file() for n in ('fit.npy','query.npy','metadata.json','normalization.npz'))
    # The called constructor cannot regenerate a cache because all frozen files exist.
    xf,xq,folder=old.features(2026,'WPAIR_DROPAB',xf,raw.copy(),wc,q)
    assert folder==weather and xf.shape==(40522,2825) and xq.shape==(102,2825)
    assert not xf[:,old.dropped()].any() and not xq[:,old.dropped()].any()
    assert all(np.isfinite(x).all() for x in (xf,xq,level,shape,wc['weights'],wc['shape_weights'],q['base160']))
    return dict(xf=xf,xq=xq,raw=raw,level=level,shape=shape,norm=norm,q=q,wc=wc,cond=meta['condition_indices'],load_seconds=time.perf_counter()-t)

def native_factory(d,seed):
    m=old.model(seed,d['cond'],'WPAIR_DROPAB',2026)
    assert sum(p.numel() for p in m.parameters())==2509761
    assert m.raw_dim==2813 and not any(p.is_cuda for p in m.parameters())
    return m

def factory(d,seed):
    return native_factory(d,seed)

def predict(m,d,x=None):
    return old.r.predict(m,d['xq'] if x is None else x,d['norm'])

def mask(x,take,choice,blocks,enabled):
    # Always consume the caller's original masking RNG stream; only the write changes.
    if enabled:
        for j,cols in enumerate(blocks):
            rr=np.flatnonzero(take&(choice==j))
            if len(rr):x[torch.from_numpy(rr)[:,None],torch.tensor(cols)[None,:]]=0.
    return x

def export(out,m,d,seed,tag,factory_fn=None):
    torch.save(dict(model=m.state_dict(),norm=d['norm'],seed=seed,identity=ID,tag=tag),out/'checkpoint.pt')
    l,s=predict(m,d);p=old.r.reconstruct(d['q']['base160'],l,s)
    assert p.shape==(102,160) and np.isfinite(p).all() and (p>0).all()
    np.savez_compressed(out/'weights.npz',**{k:v.detach().cpu().numpy() for k,v in m.state_dict().items()})
    np.savez_compressed(out/'replay_inputs.npz',x=d['xq'],base=d['q']['base160'],**d['norm'])
    np.savez_compressed(out/'issued.npz',prediction160=p,level=l,shape=s,issue_time=d['q']['issue_time'],target_start_time=d['q']['target_start_time'])
    replay=(factory_fn or factory)(d,seed);saved=torch.load(out/'checkpoint.pt',map_location='cpu',weights_only=False);replay.load_state_dict(saved['model'],strict=True)
    l2,s2=predict(replay,d)
    np.testing.assert_array_equal(l,l2);np.testing.assert_array_equal(s,s2)
    np.testing.assert_array_equal(p,old.r.reconstruct(d['q']['base160'],l2,s2))
    return p
