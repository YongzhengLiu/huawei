"""Raw, ordered province weather inputs for the single R1 model.

The weather schema, complete-city selection, and numeric operations reproduce
V1 ``build_features.read_weather``: construct [hour, variable, sorted_city] in
float32, transform each variable BEFORE the float32 city mean, then select
``t2m, ssrd, r2m`` in that order.  No load values are read here.  The stdlib CSV
reader avoids V1's pandas dependency; it does not change the feature formula.

Future weather follows the existing Perfect-weather protocol.  The reference
for future lead h is the mean of T + (h % 24) - 24*j hours, j=1,...,7.
All reference timestamps are strictly before T, including leads h >= 24.
There is no clipping, interpolation, imputation, or fold normalization.
"""
from __future__ import annotations

import csv
from functools import lru_cache
from pathlib import Path

import numpy as np


RAW_WEATHER = Path(
    "/hpc2hdd/home/yliu704/lyz/hebei_da30_0800_160_20260908/"
    "data/raw/final_hebei_weather.csv"
)
V1_FEATURE_SOURCE = Path(
    "/hpc2hdd/home/yliu704/lyz/hebei_semantic_single_mlp_v1_20260908/"
    "source/build_features.py"
)
WEATHER_VARIABLES = ("ssrd", "t2m", "tp", "d2m", "r", "q", "r2m", "ws", "wl")
SELECTED_VARIABLES = ("t2m", "ssrd", "r2m")
SELECTED_COLUMNS = tuple(WEATHER_VARIABLES.index(v) for v in SELECTED_VARIABLES)
KINDS = ("WABS", "WDELTA", "WPAIR")


def source_paths():
    """Return fixed upstream provenance paths; callers may hash these files."""
    return [RAW_WEATHER, V1_FEATURE_SOURCE]


def names(kind):
    """Column names in the exact time-major flattening order of build_extra."""
    if kind not in KINDS:
        raise ValueError(f"unknown weather feature kind: {kind}")
    absolute = [f"province_future_hour_{h}_{v}" for h in range(40) for v in SELECTED_VARIABLES]
    anomaly = [f"province_future_hour_{h}_{v}_minus_past_7d_same_clock_mean"
               for h in range(40) for v in SELECTED_VARIABLES]
    return absolute if kind == "WABS" else anomaly if kind == "WDELTA" else absolute + anomaly


def _hour_minutes(values, label):
    raw = np.asarray(values)
    if raw.ndim != 1:
        raise ValueError(f"{label} must be a one-dimensional timestamp array")
    if raw.dtype.kind in "iu":
        minute = raw.astype(np.int64, copy=False)
    else:
        precise = raw.astype("datetime64[ns]")
        rounded = precise.astype("datetime64[m]")
        if np.isnat(precise).any() or np.any(precise != rounded.astype("datetime64[ns]")):
            raise ValueError(f"{label} contains invalid or non-minute timestamps")
        minute = rounded.astype(np.int64)
    if np.any(minute % 60):
        raise ValueError(f"{label} must be on exact local-clock hours")
    return minute


class WeatherLookup:
    """V1 exact-hour lookup, generalized to arrays of requested timestamps."""
    def __init__(self, stamps):
        self.stamps = _hour_minutes(stamps, "weather stamps")
        if len(self.stamps) == 0 or np.any(np.diff(self.stamps) <= 0):
            raise ValueError("weather timestamps must be nonempty, unique, increasing")

    def exact(self, requested):
        requested = np.asarray(requested, dtype=np.int64)
        positions = np.searchsorted(self.stamps, requested)
        if np.any(positions >= len(self.stamps)):
            raise ValueError("missing exact weather hour; interpolation/extrapolation forbidden")
        if not np.array_equal(self.stamps[positions], requested):
            raise ValueError("missing exact weather hour; interpolation/extrapolation forbidden")
        return positions

    def indices(self, starts, hours):
        starts = _hour_minutes(starts, "weather window starts")
        return self.exact(starts[:, None] + 60 * np.arange(hours)[None, :])


@lru_cache(maxsize=2)
def _load_weather(path_text):
    path = Path(path_text)
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = reader.fieldnames or []
        if "timestamp" not in columns:
            raise ValueError("weather timestamp column missing")
        if len(set(columns)) != len(columns):
            raise ValueError("duplicate weather column names")
        # Exactly the V1 city selection and sorted aggregation order.
        cities = sorted(column[:-4] for column in columns
                        if column.endswith("_t2m")
                        and all(column[:-4] + "_" + v in columns for v in WEATHER_VARIABLES))
        if "石家庄市" not in cities:
            raise ValueError("all nine Shijiazhuang variables are required for the V1 schema")
        # A partially specified city must not be silently discarded in this run.
        partial = [column[:-4] for column in columns if column.endswith("_t2m")
                   and column[:-4] not in cities]
        if partial:
            raise ValueError(f"incomplete city weather columns: {partial}")
        rows = list(reader)
    if not rows:
        raise ValueError("weather CSV is empty")
    stamps = np.asarray([row["timestamp"].replace("/", "-") for row in rows], dtype="datetime64[m]")
    # Check source text precision independently before minute conversion.
    precise = np.asarray([row["timestamp"].replace("/", "-") for row in rows], dtype="datetime64[ns]")
    if np.isnat(precise).any() or np.any(precise != stamps.astype("datetime64[ns]")):
        raise ValueError("weather timestamps contain invalid or sub-minute values")
    lookup = WeatherLookup(stamps)
    tensor = np.empty((len(rows), len(WEATHER_VARIABLES), len(cities)), dtype=np.float32)
    for j, city in enumerate(cities):
        for k, variable in enumerate(WEATHER_VARIABLES):
            column = city + "_" + variable
            try:
                tensor[:, k, j] = [float(row[column]) for row in rows]
            except (ValueError, TypeError, KeyError) as exc:
                raise ValueError(f"invalid or missing weather value in {column}") from exc
    if not np.isfinite(tensor).all():
        raise ValueError("weather values must all be finite")
    # V1 fixed transforms, in the same order and in float32. t2m is already C.
    tensor[:, 0] /= 3600.0
    tensor[:, 2] *= 1000.0
    tensor[:, 3] -= 273.15
    tensor[:, 5] *= 1000.0
    province = tensor.mean(2)  # default float32 accumulation, sorted city axis
    if not np.isfinite(province).all():
        raise ValueError("transformed province weather must be finite")
    stamps.setflags(write=False)
    province.setflags(write=False)
    return dict(stamps=stamps, province=province, cities=tuple(cities), lookup=lookup,
                variables=WEATHER_VARIABLES, path=path)


def load_weather(path=None):
    """Lazily cache raw weather; optional path supports local verification."""
    return _load_weather(str(RAW_WEATHER if path is None else Path(path)))


def _components(issues, weather):
    minute = _hour_minutes(issues, "issue times")
    if tuple(weather.get("variables", WEATHER_VARIABLES)) != WEATHER_VARIABLES:
        raise ValueError("province variable order differs from the V1 schema")
    province = np.asarray(weather["province"])
    if province.shape != (len(weather["stamps"]), 9) or province.dtype != np.float32:
        raise ValueError("province weather must be float32 [hour, 9] in V1 order")
    if not np.isfinite(province).all():
        raise ValueError("province weather must be finite")
    lookup = weather.get("lookup") or WeatherLookup(weather["stamps"])
    future_times = minute[:, None] + 60 * np.arange(40)[None, :]
    history_times = (minute[:, None, None]
                     + 60 * (np.arange(40) % 24)[None, :, None]
                     - 1440 * np.arange(1, 8)[None, None, :])
    if np.any(history_times >= minute[:, None, None]):
        raise AssertionError("same-clock weather reference is not strictly observed")
    future = province[lookup.exact(future_times)][:, :, SELECTED_COLUMNS]
    reference = province[lookup.exact(history_times)][:, :, :, SELECTED_COLUMNS].mean(2)
    anomaly = future - reference
    return future, anomaly, reference, future_times, history_times


def build_extra(issues, kind, weather=None):
    """Build WABS/WDELTA[120] or WPAIR[240] without normalization."""
    if kind not in KINDS:
        raise ValueError(f"unknown weather feature kind: {kind}")
    weather = load_weather() if weather is None else weather
    future, anomaly, _, _, _ = _components(issues, weather)
    absolute, delta = future.reshape(len(future), 120), anomaly.reshape(len(anomaly), 120)
    result = absolute if kind == "WABS" else delta if kind == "WDELTA" else np.concatenate((absolute, delta), 1)
    if result.shape[1] != len(names(kind)) or not np.isfinite(result).all():
        raise AssertionError("weather feature shape or finiteness check failed")
    return np.ascontiguousarray(result, dtype=np.float32)


def causality_audit(issues, weather=None):
    """Check timestamp bounds and values via independent calendar-hour lookup.

    Future weather is intentionally allowed. Only the anomaly reference is
    required to precede issue; no future target load is used by this module.
    """
    weather = load_weather() if weather is None else weather
    minute = _hour_minutes(issues, "audit issue times")
    if len(minute) == 0:
        raise ValueError("causality audit requires at least one issue")
    future, anomaly, reference, future_times, history_times = _components(issues, weather)
    exact = {int(t): i for i, t in enumerate(_hour_minutes(weather["stamps"], "audit weather stamps"))}
    selected = np.asarray(weather["province"])[:, SELECTED_COLUMNS]
    max_value_error = 0.0
    # Independent formula finds the latest strictly observed occurrence of
    # each future LOCAL hour, then walks back by whole days.
    for i, current in enumerate(minute):
        for h in (0, 7, 16, 23, 24, 39):
            target = int(current + h * 60)
            clock = target % 1440
            latest = int((current // 1440) * 1440 + clock)
            if latest >= current:
                latest -= 1440
            reference_times = np.array([latest - j * 1440 for j in range(7)], dtype=np.int64)
            np.testing.assert_array_equal(reference_times, history_times[i, h])
            if not np.all(reference_times < current):
                raise AssertionError("independent reference reaches issue or later")
            direct = selected[exact[target]]
            mean = np.stack([selected[exact[int(t)]] for t in reference_times]).mean(0)
            np.testing.assert_array_equal(direct, future[i, h])
            np.testing.assert_allclose(mean, reference[i, h], rtol=2e-6, atol=1e-5)
            np.testing.assert_allclose(direct - mean, anomaly[i, h], rtol=2e-6, atol=1e-5)
            max_value_error = max(max_value_error, float(np.max(np.abs(mean - reference[i, h]))))
    np.testing.assert_array_equal(future_times, minute[:, None] + np.arange(40)[None, :] * 60)
    return dict(issues=len(minute), checked_leads=[0, 7, 16, 23, 24, 39],
                source_cities=list(weather["cities"]), selected_variables=list(SELECTED_VARIABLES),
                province_variable_indices=list(SELECTED_COLUMNS),
                reference_strictly_before_issue=True, future_weather_protocol="Perfect-weather",
                reference_oldest_hours_before_issue=float(np.max((minute[:, None, None] - history_times) / 60)),
                reference_newest_hours_before_issue=float(np.min((minute[:, None, None] - history_times) / 60)),
                independent_value_max_abs=max_value_error, raw_weather=str(weather["path"]))
