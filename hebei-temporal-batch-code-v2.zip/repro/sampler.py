"""Fixed fullcoverage temporalbatch mapping. No RNG calls, labels or query inputs."""
import numpy as np
ARM='TEMPORAL_STRATIFIED_BATCH'
def order(native,chronological,enabled=True,batch=256):
    p=np.asarray(native);chron=np.asarray(chronological);n=len(p)
    assert p.ndim==chron.ndim==1 and len(chron)==n and n>=batch
    if not enabled:return p.copy()
    # Both inputs are permutations; audited once on actual source in PF.
    rank=np.empty(n,dtype=np.int64);rank[p]=np.arange(n)
    residues=p%batch
    _,first=np.unique(residues,return_index=True)
    priority=residues[np.sort(first)];assert len(priority)==batch
    sizes=np.full(batch,n//batch,dtype=np.int64);sizes[priority[:n%batch]]+=1
    binid=np.repeat(np.arange(batch),sizes)
    grouped=chron[np.lexsort((rank[chron],binid))]
    depth=np.arange(n)-np.repeat(np.cumsum(sizes)-sizes,sizes)
    return grouped[np.lexsort((rank[grouped],depth))]

def metadata(native,chronological,candidate,batch=256):
    p=np.asarray(native);c=np.asarray(candidate);n=len(p)
    assert n==40522 and np.array_equal(np.sort(p),np.arange(n)) and np.array_equal(np.sort(chronological),np.arange(n)) and np.array_equal(np.sort(c),np.arange(n))
    residues=p%batch;_,first=np.unique(residues,return_index=True);priority=residues[np.sort(first)]
    sizes=np.full(batch,n//batch,dtype=np.int64);sizes[priority[:n%batch]]+=1
    rowbin=np.empty(n,dtype=np.int64);rowbin[chronological]=np.repeat(np.arange(batch),sizes)
    lengths=[]
    for left in range(0,n,batch):
        bins=rowbin[c[left:left+batch]];assert len(np.unique(bins))==len(bins)
        if len(bins)==batch:assert np.array_equal(np.sort(bins),np.arange(batch))
        else:assert np.array_equal(np.sort(bins),np.sort(priority[:n%batch]))
        lengths.append(len(bins))
    assert lengths==[256]*158+[74]
    return dict(all40522_once=True,fullbatch_each_timebin_once=True,last74_randomized_longbins=True,batch_sizes=lengths,bins=256)
