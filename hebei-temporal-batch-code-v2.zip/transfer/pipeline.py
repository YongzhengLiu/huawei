"""Model-independent preparation orchestration, with no scoring-truth API."""
import importlib,json,hashlib
import numpy as np
from .contracts import WindowSpec

def component(spec):
    module,name=spec['target'].split(':',1)
    return getattr(importlib.import_module(module),name)(**spec.get('kwargs',{}))

def cache_fingerprint(config,backend_fingerprint):
    return hashlib.sha256(json.dumps(dict(config=config,backend=backend_fingerprint),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def prepare_for_transfer(dataset,backend,feature_builder,window_spec,allow_perfect_weather=False):
    """The caller supplies a dataset-specific FeatureBuilder/CorrectorRunner.

    It cannot reuse Hebei frozen feature caches after changing the FM or schema.
    """
    query=dataset.load_query();fit=dataset.load_fit()
    query.validate(window_spec,allow_perfect_weather=allow_perfect_weather)
    assert len(query.issue_time)>0
    fit.windows.validate(window_spec,allow_perfect_weather=allow_perfect_weather)
    y=fit.future_target;assert y.shape==(len(fit.windows.issue_time),window_spec.horizon) and np.isfinite(y).all() and (y>0).all()
    end=fit.windows.issue_time.astype('datetime64[m]')+np.timedelta64((window_spec.horizon-1)*window_spec.frequency_minutes,'m')
    assert np.all(end<query.issue_time.astype('datetime64[m]').min()),'Fit target not mature at first query'
    base_fit=backend.predict(fit.windows,window_spec).validate(len(fit.windows.issue_time),window_spec)
    feature_builder.fit(fit,base_fit)
    train_features=feature_builder.transform(fit.windows,base_fit)
    base_query=backend.predict(query,window_spec).validate(len(query.issue_time),window_spec)
    query_features=feature_builder.transform(query,base_query)
    return dict(fit_features=train_features,query_features=query_features,fit_targets=fit,query_windows=query,base_fit=base_fit,base_query=base_query,feature_state=feature_builder.state_dict(),backend_fingerprint=backend.fingerprint())
