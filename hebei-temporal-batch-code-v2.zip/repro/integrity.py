"""Verify immutable bundle bytes; hashing never parses labels or model arrays."""
from pathlib import Path
import json,hashlib
from paths import PACKAGE,SNAPSHOT

def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def verify_payload():
    manifest=json.loads((PACKAGE/'PAYLOAD_MANIFEST.json').read_text())
    total=0
    for name,v in manifest['files'].items():
        p=SNAPSHOT/name
        assert SNAPSHOT in p.resolve().parents and p.is_file() and not p.is_symlink(),name
        assert p.stat().st_size==v['bytes'] and digest(p)==v['SHA'],name
        total+=v['bytes']
    return dict(all_files_SHA_verified=True,files=len(manifest['files']),bytes=total,querytruth_parsed=False)
