"""Source-audited, data-independent column types for the V5 2,585-D input.

All ranges are zero-based and half-open.  This module never reads target
values or estimates feature types from validation/test distributions.  The
first 2,573 columns reproduce the V1 S1 cache; the final 12 are V3 causal
Chronos bias states.  ``bounded_indices`` receive train-mean centering with
unit scale in the typed-normalization treatment.  All other columns retain
the baseline train-only z-score convention.

``mask_blocks`` contains three disjoint auxiliary blocks.  A training mask
must be applied ONCE to the normalized 2,585-D tensor, before either branch
or FiLM extracts a view.  Fill with zero (= the training mean); do not use
inverted-dropout amplification.  Prefix observations and bias states are
protected, as are the base forecast, load statistics, and all calendar data.
"""
from __future__ import annotations

import hashlib
import json


RAW_DIM = 2573
INPUT_DIM = 2585
DAY_TYPES = ("normal_workday", "weekend", "official_holiday", "makeup_workday")
HOLIDAY_TYPES = ("none", "new_year", "spring_festival", "qingming", "labor_day",
                 "dragon_boat", "mid_autumn", "national_day", "mid_autumn_national")
CNY_PHASES = ("none", "pre_14", "spring_holiday", "return_1_3", "return_4_14")
WEATHER_VARIABLES = ("ssrd", "t2m", "tp", "d2m", "r", "q", "r2m", "ws", "wl")
OPS = ("mean", "std", "min", "max", "last_minus_first", "slope")


def _summary(windows, variables):
    return [f"window_{w}_{op}_{var}" for w in windows for op in OPS for var in variables]


def _degree(windows):
    return [f"window_{w}_t2m_{kind}_degree_{threshold}"
            for w in windows for threshold in (10, 18, 24, 28) for kind in ("cold", "hot")]


def get_schema():
    """Return a fresh, JSON-serializable dictionary with exact column metadata.

    Relevant keys: ``bounded_indices`` (583 ints), ``continuous_indices``
    (2,002 ints), ``mask_blocks`` (name -> list of ints), ``dimensions``
    (ordered source block -> width), ``blocks``, ``columns`` (all 2,585),
    ``protected_prefix_indices``, ``raw_dim``, and ``input_dim``.
    """
    columns, blocks, dimensions = [], {}, {}

    def add_block(name, semantics, bounded=False, bounds=None, source_names=None):
        start = len(columns)
        dimensions[name] = len(semantics)
        blocks[name] = {"start": start, "end_exclusive": start + len(semantics),
                        "width": len(semantics)}
        for local, semantic in enumerate(semantics):
            is_bounded = bounded if isinstance(bounded, bool) else bounded[local]
            bound = bounds if bounds is None or len(bounds) == 2 and isinstance(bounds[0], (int, float)) else bounds[local]
            cache_name = source_names[local] if source_names is not None else f"{name}_{local:04d}"
            columns.append({"index": start + local, "block": name, "local_index": local,
                            "name": f"{name}/{semantic}", "cache_name": cache_name,
                            "normalization": "center_only" if is_bounded else "train_zscore",
                            "semantic_bounds": list(bound) if bound is not None else None})

    add_block("scene", [f"embedding_{j}" for j in range(768)])
    add_block("base_tail96_normalized", [f"tail_step_{j}" for j in range(96)])
    load_stats = ([f"context_{s}" for s in _summary((4, 16, 96, 288, 672), ("load",))]
                  + [f"context_last_minus_lag_{j}_over_context_std" for j in (4, 96, 192, 672)]
                  + [f"tail_forecast_{s}" for s in _summary((24, 48, 96), ("load",))]
                  + [f"tail_quantile_width_over_context_std_{op}" for op in ("mean", "std", "max")]
                  + ["log_context_mean", "log_context_std"])
    add_block("load_and_tail_forecast_stats", load_stats)
    add_block("calendar_tail_start", [f"{period}_{trig}" for period in ("hour", "weekday", "year_day")
                                      for trig in ("sin", "cos")], True, (-1, 1))
    add_block("sjz_past_weather", _summary((6, 24, 72, 168), WEATHER_VARIABLES) + _degree((24, 72, 168)))
    add_block("sjz_tail24_weather", _summary((6, 12, 24), WEATHER_VARIABLES) + _degree((6, 12, 24)))

    basic = ([f"current_{v}" for v in DAY_TYPES]
             + [f"past_day_{j}_{v}" for j in range(1, 8) for v in DAY_TYPES]
             + [f"future_hour_{j}_{v}" for j in range(24) for v in DAY_TYPES])
    add_block("h3_day_type", basic, True, (0, 1))
    category = ([f"current_{v}" for v in HOLIDAY_TYPES]
                + [f"future_hour_{j}_{v}" for j in range(24) for v in HOLIDAY_TYPES])
    add_block("h3_holiday_category", category, True, (0, 1))
    phase = ([f"current_{v}" for v in CNY_PHASES]
             + [f"future_hour_{j}_{v}" for j in range(24) for v in CNY_PHASES]
             + [f"current_cny_distance_rbf_center_{j}_width_3" for j in (-14, -7, -3, 0, 3, 7, 14)]
             + ["current_clipped_cny_distance_over_30"]
             + [f"future_hour_{j}_clipped_cny_distance_over_30" for j in range(24)])
    add_block("h3_cny_phase", phase, True, [(0, 1)] * 132 + [(-1, 1)] * 25)
    add_block("base_bridge64_normalized", [f"bridge_step_{j}" for j in range(64)])
    add_block("province_full40_summary", _summary((8, 16, 24, 40), WEATHER_VARIABLES))
    add_block("city_dispersion_full40_summary", _summary((8, 16, 24, 40), WEATHER_VARIABLES))
    add_block("province_full40_degree", _degree((8, 16, 24, 40)))
    full_calendar, full_bounds = [], []
    for window in ("bridge_0_16", "tail_16_40", "full_0_40"):
        for kind, vocabulary in (("day_type", DAY_TYPES), ("holiday", HOLIDAY_TYPES), ("phase", CNY_PHASES)):
            full_calendar.extend(f"{window}_{kind}_{v}_fraction" for v in vocabulary)
            full_bounds.extend([(0, 1)] * len(vocabulary))
        full_calendar.extend((f"{window}_clipped_cny_distance_mean", f"{window}_clipped_cny_distance_std"))
        full_bounds.extend(((-1, 1), (0, 1)))
    add_block("calendar_full40", full_calendar, True, full_bounds)

    event_names = ([f"event_shape_mean_{j:02d}" for j in range(96)]
                   + ["event_active", "event_reference_missing", "event_history_years",
                      "event_log_level_mean", "event_log_level_std", "event_shape_rms_dispersion"])
    prefix_names = (["prefix_observed_fraction", "prefix_actual_missing", "prefix_weekly_missing",
                     "prefix_weekly_count", "prefix_log_mean_ratio", "prefix_relative_mean",
                     "prefix_relative_std", "prefix_relative_min", "prefix_relative_max",
                     "prefix_relative_last", "prefix_relative_delta", "prefix_relative_slope"]
                    + [f"prefix_relative_dct_{j}" for j in range(8)])
    event_prefix_names = event_names + prefix_names
    bounded_local = {96, 97, 102, 103, 104}
    add_block("causal_event_and_prefix", event_prefix_names,
              [j in bounded_local for j in range(122)],
              [(0, 1) if j in bounded_local else None for j in range(122)], event_prefix_names)

    bias_names = ([f"chronos_mature_last_{g}_log_bias" for g in ("all", "day_08_20", "night")]
                  + [f"chronos_mature_7d_mean_{g}_log_bias" for g in ("all", "day_08_20", "night")]
                  + [f"chronos_mature_7d_std_{g}_log_bias" for g in ("all", "day_08_20", "night")]
                  + ["chronos_visible_8h_prefix_log_bias", "chronos_mature_7d_valid_fraction",
                     "chronos_visible_8h_prefix_valid"])
    add_block("causal_bias", bias_names, [False] * 10 + [True] * 2,
              [None] * 10 + [(0, 1)] * 2, bias_names)

    masks = {"scene": list(range(0, 768)),
             "weather": list(range(927, 1353)) + list(range(1927, 2391)),
             "historical_event": list(range(2451, 2553))}
    schema = {
        "version": "v5_source_types_20260908", "index_convention": "zero-based half-open",
        "raw_dim": RAW_DIM, "input_dim": INPUT_DIM, "dimensions": dimensions, "blocks": blocks,
        "columns": columns,
        "bounded_indices": [c["index"] for c in columns if c["normalization"] == "center_only"],
        "continuous_indices": [c["index"] for c in columns if c["normalization"] == "train_zscore"],
        "mask_blocks": masks, "protected_prefix_indices": list(range(2553, 2573)),
        "protected_bias_indices": list(range(2573, 2585)),
        "mask_policy": "One shared mask on normalized full x before Level/Shape/FiLM; zero fill is train mean; no amplification; inference unmasked.",
        "typing_policy": "Fixed source semantics only; center bounded one-hot/fractions/sin-cos/clipped distances/RBF; z-score load/weather/scene/event curves/counts/log-bias on training rows only.",
        "source_contract": ["V1 source/build_features.py", "V1 source/holidays.py",
                            "V3 source/causal_bias.py", "V3 source/model.py"],
    }
    validate_schema(schema)
    schema["schema_sha256"] = hashlib.sha256(json.dumps(schema, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    return schema


def validate_schema(schema):
    """Fail closed on dimensional, overlap, or protected-feature mistakes."""
    assert schema["raw_dim"] == 2573 and schema["input_dim"] == 2585
    assert len(schema["columns"]) == sum(schema["dimensions"].values()) == INPUT_DIM
    assert [c["index"] for c in schema["columns"]] == list(range(INPUT_DIM))
    assert len({c["name"] for c in schema["columns"]}) == INPUT_DIM
    assert len({c["cache_name"] for c in schema["columns"]}) == INPUT_DIM
    bounded, continuous = map(set, (schema["bounded_indices"], schema["continuous_indices"]))
    assert len(bounded) == 583 and len(continuous) == 2002
    assert not bounded & continuous and bounded | continuous == set(range(INPUT_DIM))
    assert all(schema["columns"][j]["semantic_bounds"] is not None for j in bounded)
    masks = schema["mask_blocks"]
    assert {k: len(v) for k, v in masks.items()} == {"scene": 768, "weather": 890, "historical_event": 102}
    flat = [j for indices in masks.values() for j in indices]
    assert len(flat) == len(set(flat)) and all(0 <= j < INPUT_DIM for j in flat)
    assert not set(flat) & set(schema["protected_prefix_indices"] + schema["protected_bias_indices"])
    assert set(range(2451, 2547)).isdisjoint(bounded), "Event curves are not one-hot/proportions."
    assert {2549, 2556}.isdisjoint(bounded), "Historical-year and weekly counts retain z-score."
    assert {2547, 2548, 2553, 2554, 2555, 2583, 2584}.issubset(bounded)
    assert schema["blocks"]["causal_bias"]["start"] == RAW_DIM
    return True


def validate_feature_names(feature_names, bias_names=None):
    """Verify actual cache ordering against every source-generated column name."""
    schema = get_schema()
    actual = [str(n) for n in feature_names]
    expected = [c["cache_name"] for c in schema["columns"][:RAW_DIM]]
    if actual != expected:
        first = next((j for j, (a, b) in enumerate(zip(actual, expected)) if a != b), None)
        raise ValueError(f"Raw feature-name/order mismatch: lengths={len(actual)}/{len(expected)}, first_difference={first}")
    if bias_names is not None and [str(n) for n in bias_names] != [c["cache_name"] for c in schema["columns"][RAW_DIM:]]:
        raise ValueError("Causal-bias feature-name/order mismatch")
    return True


if __name__ == "__main__":
    result = get_schema()
    print(json.dumps({k: result[k] for k in ("version", "raw_dim", "input_dim", "dimensions", "schema_sha256")}, indent=2))
    print(json.dumps({"bounded": len(result["bounded_indices"]), "zscore": len(result["continuous_indices"]),
                      "mask_widths": {k: len(v) for k, v in result["mask_blocks"].items()}}, indent=2))


