from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np


DAY_TYPES = ("normal_workday", "weekend", "official_holiday", "makeup_workday")
HOLIDAY_TYPES = (
    "none", "new_year", "spring_festival", "qingming", "labor_day",
    "dragon_boat", "mid_autumn", "national_day", "mid_autumn_national",
)
CNY_PHASES = ("none", "pre_14", "spring_holiday", "return_1_3", "return_4_14")


def _date(value: str) -> date:
    return datetime.strptime(value, "%Y-%m-%d").date()


class OfficialCalendar:
    def __init__(self, config_path: str | Path):
        payload = json.loads(Path(config_path).read_text(encoding="utf-8"))
        self.holidays: dict[date, str] = {}
        self.makeup: set[date] = set()
        self.cny: dict[int, date] = {}
        self.spring: dict[int, tuple[date, date]] = {}
        for year_text, record in payload["years"].items():
            year = int(year_text)
            self.cny[year] = _date(record["cny_new_year"])
            self.spring[year] = tuple(_date(value) for value in record["spring_festival"])
            for name, start_text, end_text in record["holidays"]:
                current, end = _date(start_text), _date(end_text)
                while current <= end:
                    self.holidays[current] = name
                    current += timedelta(days=1)
            self.makeup.update(_date(value) for value in record["makeup_workdays"])
        self.years = frozenset(self.cny)
        self.first_year = min(self.years)
        self.last_year = max(self.years)

    def state(self, value: date) -> tuple[str, str, str, int]:
        if value.year not in self.years:
            raise ValueError(
                f"holiday calendar covers {self.first_year}-{self.last_year}, "
                f"but features require {value}; extend the calendar JSON before training"
            )
        if value in self.holidays:
            day_type = "official_holiday"
        elif value in self.makeup:
            day_type = "makeup_workday"
        else:
            day_type = "weekend" if value.weekday() >= 5 else "normal_workday"
        holiday_type = self.holidays.get(value, "none")
        cny_candidates = [item for year, item in self.cny.items() if abs(year - value.year) <= 1]
        distance = min(((value - item).days for item in cny_candidates), key=abs)
        spring_year = min(self.spring, key=lambda year: abs((value - self.spring[year][0]).days))
        start, end = self.spring[spring_year]
        if start <= value <= end:
            phase = "spring_holiday"
        elif -14 <= (value - start).days <= -1:
            phase = "pre_14"
        elif 1 <= (value - end).days <= 3:
            phase = "return_1_3"
        elif 4 <= (value - end).days <= 14:
            phase = "return_4_14"
        else:
            phase = "none"
        return day_type, holiday_type, phase, distance


def one_hot(value: str, vocabulary: tuple[str, ...]) -> np.ndarray:
    output = np.zeros(len(vocabulary), dtype=np.float32)
    output[vocabulary.index(value)] = 1.0
    return output


def feature_blocks(origin_time: np.ndarray, calendar: OfficialCalendar, future_hours: int = 24):
    basic_rows, category_rows, phase_rows = [], [], []
    centers = np.asarray((-14, -7, -3, 0, 3, 7, 14), dtype=np.float32)
    epoch = datetime(1970, 1, 1)
    for raw in origin_time.astype("datetime64[m]").astype(np.int64):
        origin = epoch + timedelta(minutes=int(raw))
        current = origin.date()
        current_state = calendar.state(current)
        past = [calendar.state(current - timedelta(days=offset)) for offset in range(1, 8)]
        future = [calendar.state((origin + timedelta(hours=offset)).date()) for offset in range(future_hours)]
        basic = [one_hot(current_state[0], DAY_TYPES)]
        basic.extend(one_hot(item[0], DAY_TYPES) for item in past)
        basic.extend(one_hot(item[0], DAY_TYPES) for item in future)
        category = [one_hot(current_state[1], HOLIDAY_TYPES)]
        category.extend(one_hot(item[1], HOLIDAY_TYPES) for item in future)
        distance = float(np.clip(current_state[3], -30, 30))
        phase = [one_hot(current_state[2], CNY_PHASES)]
        phase.extend(one_hot(item[2], CNY_PHASES) for item in future)
        phase.append(np.exp(-0.5 * np.square((distance - centers) / 3.0)).astype(np.float32))
        phase.append(np.asarray([distance / 30.0], dtype=np.float32))
        phase.append(np.asarray([np.clip(item[3], -30, 30) / 30.0 for item in future], dtype=np.float32))
        basic_rows.append(np.concatenate(basic))
        category_rows.append(np.concatenate(category))
        phase_rows.append(np.concatenate(phase))
    return (
        np.asarray(basic_rows, dtype=np.float32),
        np.asarray(category_rows, dtype=np.float32),
        np.asarray(phase_rows, dtype=np.float32),
    )
