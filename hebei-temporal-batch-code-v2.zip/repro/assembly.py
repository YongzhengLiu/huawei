import copy,hashlib,numpy as np,torch
from paths import SNAPSHOT
from features import names
import engine as r
ROOT=SNAPSHOT/'hebei_r1_goal98_20261013'
def write(*args,**kwargs):raise RuntimeError('Frozen cache missing; implicit cache generation is disabled')

def insert(x,z):return np.concatenate((x[:,:2573],z,x[:,2573:]),axis=1).astype(np.float32)

def features(year,cid,xf,xq,wc,q):
    if cid not in ('WABS','WDELTA','WPAIR'):return xf,xq,None
    folder=ROOT/f'data/year_{year}/{cid}'
    if folder.exists():
        meta=r.read(folder/'metadata.json');assert meta['feature_source']==r.sha(ROOT/'source/features.py')
        assert meta['fit_issue_sha']==hashlib.sha256(wc['issue_time'].tobytes()).hexdigest()
        assert meta['query_issue_sha']==hashlib.sha256(q['issue_time'].tobytes()).hexdigest()
        a=np.load(folder/'fit.npy');b=np.load(folder/'query.npy')
    else:
        a=build_extra(wc['issue_time'],cid);b=build_extra(q['issue_time'],cid)
        mean=a.mean(0,dtype=np.float64).astype(np.float32);std=a.std(0,dtype=np.float64).astype(np.float32)
        std=np.where(std<1e-6,1.,std).astype(np.float32)
        a=((a-mean)/std).astype(np.float32);b=((b-mean)/std).astype(np.float32)
        assert np.isfinite(a).all() and np.isfinite(b).all()
        folder.mkdir(parents=True);np.save(folder/'fit.npy',a);np.save(folder/'query.npy',b)
        np.savez_compressed(folder/'normalization.npz',mean=mean,std=std)
        write(folder/'metadata.json',dict(feature_names=names(cid),feature_source=r.sha(ROOT/'source/features.py'),fit_issue_sha=hashlib.sha256(wc['issue_time'].tobytes()).hexdigest(),query_issue_sha=hashlib.sha256(q['issue_time'].tobytes()).hexdigest(),fit_only_normalization=True))
    assert a.shape==(len(xf),len(names(cid))) and b.shape==(len(xq),len(names(cid)))
    return insert(xf,a),insert(xq,b),folder

def expanded_linear(old,cols,width):
    with torch.random.fork_rng(devices=[]):new=torch.nn.Linear(width,old.out_features)
    with torch.no_grad():
        new.weight.zero_();new.weight[:,cols]=old.weight;new.bias.copy_(old.bias)
    return new

def model(seed,cond,cid):
    m=r.model(seed,cond,'normal')
    if cid in ('WABS','WDELTA','WPAIR'):
        d=len(names(cid));mapping=list(range(2573))+list(range(2573+d,2585+d))
        m.level.net[0]=expanded_linear(m.level.net[0],mapping,2585+d)
        m.shape.net[0]=expanded_linear(m.shape.net[0],list(range(2573)),2573+d)
        m.condition[0]=expanded_linear(m.condition[0],list(range(len(cond))),len(cond)+d)
        m.raw_dim=2573+d
        m.cond_idx=torch.tensor([mapping[j] for j in cond]+list(range(2573,2573+d)),dtype=torch.long)
    elif cid=='LSKIP':
        with torch.random.fork_rng(devices=[]):m.direct_level=torch.nn.Linear(2585,1)
        torch.nn.init.zeros_(m.direct_level.weight);torch.nn.init.zeros_(m.direct_level.bias)
        ordinary=m.forward_level
        m.forward_level=lambda x:ordinary(x)+m.direct_level(x)
    return m

def mask_blocks(cid):
    s=copy.deepcopy(r.get_schema()['mask_blocks']);d=len(names(cid)) if cid.startswith('W') else 0
    if d:s['weather']+=list(range(2573,2573+d))
    return list(s.values())
