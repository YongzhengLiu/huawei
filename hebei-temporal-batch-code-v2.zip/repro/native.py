"""The original native D2 objective; no quotient/conditional targets."""
from core import old

def losses(pl,ps,lt,st,w,ws,recipe):
    terms=old.r.losses(pl,ps,lt,st,w,ws,recipe,{},None,None,None)
    assert len(terms)==3
    return terms
