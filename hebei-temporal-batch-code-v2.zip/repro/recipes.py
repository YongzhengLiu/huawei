"""Frozen V10 single-model recipes; no data loading or experiment submission.

All ordinary losses reduce as mean(weight * per_sample_loss).  For the A1
sampler the returned weights are importance ratios for its 64/192 proposal,
not the original fit-population weights.  ``losses`` returns the already-scaled
E1 auxiliary contribution, so callers add its three returned scalars directly.

F parameter averaging is averaging U and V separately along one trajectory.
It is deliberately NOT averaging the expanded matrices U @ V.
"""
from __future__ import annotations

import math

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from base_model import BiasConditionModel


BASE_CANDIDATES = tuple(
    [f'A{i}' for i in range(1, 7)]
    + [f'B{i}' for i in range(1, 6)]
    + [f'C{i}' for i in range(3)]
    + [f'D{i}' for i in range(1, 7)]
    + [f'E{i}' for i in range(1, 3)]
    + [f'F{i}' for i in range(1, 3)]
)
REFERENCE_CANDIDATES = ('V9_JS50', 'V9_J')

_CHANGES = {
    'A1': {'sampler': 'stratified'},
    'A2': {'clock_schedule': 'curriculum'},
    'A3': {'clock_schedule': 'integral'},
    'A4': {'epochs': 64, 'average_start': 33},
    'A5': {'epochs': 160, 'average_start': 129},
    'A6': {'epochs': 160, 'average_start': 129, 'lr_schedule': 'cosine'},
    'B1': {'level_dropout': 0.1},
    'B2': {'level_dropout': 0.3},
    'B3': {'level_weight_decay': 0.003, 'split_optimizer': True},
    'B4': {'level_weight_decay': 0.01, 'split_optimizer': True},
    'B5': {'level_lr_multiplier': 0.5, 'split_optimizer': True},
    'C0': {'consistency_beta': 0.0},
    'C1': {'consistency_beta': 0.1},
    'C2': {'consistency_beta': 0.3},
    'D1': {'level_distribution': 'season'},
    'D2': {'level_distribution': 'year_equal'},
    'D3': {'level_distribution': 'recency', 'recency_half_life_days': 365.0},
    'D4': {'level_distribution': 'recency', 'recency_half_life_days': 730.0},
    'D5': {'level_distribution': 'spring', 'spring_coefficient': 0.5},
    'D6': {'level_distribution': 'spring', 'spring_coefficient': 1.0},
    'E1': {'auxiliary_tail_mean_coefficient': 0.1},
    'E2': {'project_shape_loss': True},
    'F1': {'level_rank': 64},
    'F2': {'level_rank': 128},
}


def resolve(candidate, components=None, shape_mass_override=None):
    """Resolve one of the 24 candidates, two references, or fixed K1--K4.

    Components are base-candidate IDs, never trained checkpoints.  Combination
    eligibility/selection is the caller's responsibility; this function enforces
    only the preregistered structural rules and cannot inspect scores.
    """
    if not isinstance(candidate, str):
        raise TypeError('candidate must be an ID string')
    supplied_components = [] if components is None else list(components)
    if candidate in BASE_CANDIDATES:
        if supplied_components:
            raise ValueError('A base candidate cannot also have components')
        chosen = [candidate]
    elif candidate in REFERENCE_CANDIDATES:
        if supplied_components or shape_mass_override is not None:
            raise ValueError('Reference recipes cannot be modified')
        chosen = []
    elif candidate in ('K1', 'K2', 'K3', 'K4'):
        chosen = supplied_components
        if not chosen or any(item not in BASE_CANDIDATES for item in chosen):
            raise ValueError('K recipes require registered base components')
        families = [item[0] for item in chosen]
        if len(set(families)) != len(families):
            raise ValueError('At most one component from a given family')
        valid = {
            'K1': len(chosen) == 2 and set(families) == {'A', 'B'},
            'K2': len(chosen) == 2 and 'D' in families
                  and any(family in families for family in ('B', 'C')),
            'K3': len(chosen) == 2 and any(family in families for family in ('B', 'C'))
                  and any(family in families for family in ('E', 'F')),
            'K4': len(chosen) == 1,
        }[candidate]
        if not valid:
            raise ValueError('Undefined preregistered combination: ' + candidate)
        if candidate == 'K4':
            if shape_mass_override is None:
                shape_mass_override = 0.25
            if float(shape_mass_override) != 0.25:
                raise ValueError('K4 is specifically the Shape25 J cross-control')
        elif shape_mass_override is not None:
            raise ValueError('Only K4 changes the combination base to J')
    else:
        raise ValueError('Unregistered candidate: ' + candidate)
    # Exposing an override on a base ID permits direct, testable K4-equivalent
    # resolution by callers; the registered candidate list is not expanded.
    if shape_mass_override is not None and float(shape_mass_override) != 0.25:
        raise ValueError('The only preregistered Shape mass override is 0.25')
    shape_mass = 0.25 if candidate == 'V9_J' else 0.5
    if shape_mass_override is not None:
        shape_mass = float(shape_mass_override)
    recipe = {
        'candidate': candidate,
        'family': candidate[0] if candidate in BASE_CANDIDATES else ('K' if chosen else 'reference'),
        'components': chosen,
        'base': 'V9_J' if shape_mass == 0.25 else 'V9_JS50',
        'shape_mass_override': shape_mass_override,
        'epochs': 96,
        'average_start': 65,
        'sampler': 'uniform',
        'stratified_batch08': 64,
        'stratified_batch_other': 192,
        'level_mass': 0.5,
        'shape_mass': shape_mass,
        'clock_schedule': 'constant',
        'lr_schedule': 'constant',
        'minimum_lr': 1e-5,
        'level_dropout': None,
        'level_weight_decay': None,
        'level_lr_multiplier': 1.0,
        'split_optimizer': False,
        'consistency_beta': None,
        'level_distribution': 'uniform',
        'recency_half_life_days': None,
        'spring_coefficient': None,
        'auxiliary_tail_mean_coefficient': 0.0,
        'project_shape_loss': False,
        'level_rank': None,
        'normalization': 'unchanged_unweighted_fit_norm',
        'gradient_clip': 'global_1',
        'parameter_averaging': 'same_trajectory_parameters',
        'low_rank_averaging': 'mean(U)@mean(V), not mean(U@V)',
    }
    for item in chosen:
        recipe.update(_CHANGES[item])
    recipe['average_epochs'] = list(range(recipe['average_start'], recipe['epochs'] + 1))
    if len(recipe['average_epochs']) != 32:
        raise AssertionError('Every registered recipe averages exactly 32 epochs')
    return recipe


def _curriculum(epoch, population_mass, final_mass):
    if epoch <= 16:
        return population_mass
    if epoch <= 32:
        return population_mass + (final_mass - population_mass) * (epoch - 16) / 16
    return final_mass


def clock_masses(recipe, epoch, p08):
    """Actual epoch masses; A3 integrates the 96 discrete A2 values."""
    if not 0 < float(p08) < 1:
        raise ValueError('Both 08 and other clocks must be present')
    if int(epoch) != epoch or not 1 <= epoch <= recipe['epochs']:
        raise ValueError('epoch is one-based and must be in this recipe budget')
    output = []
    for final in (recipe['level_mass'], recipe['shape_mass']):
        if recipe['clock_schedule'] == 'curriculum':
            value = _curriculum(epoch, float(p08), final)
        elif recipe['clock_schedule'] == 'integral':
            value = math.fsum(_curriculum(e, float(p08), final) for e in range(1, 97)) / 96
        elif recipe['clock_schedule'] == 'constant':
            value = final
        else:
            raise ValueError('Unknown clock schedule')
        output.append(float(value))
    return tuple(output)


class LowRankLinear(nn.Module):
    """One linear UV factorization with the original, unchanged bias."""

    def __init__(self, original, rank):
        super().__init__()
        if not isinstance(original, nn.Linear):
            raise TypeError('Only the original Level first Linear may be replaced')
        if not 0 < rank <= min(original.weight.shape):
            raise ValueError('Invalid truncated rank')
        self.in_features, self.out_features = original.in_features, original.out_features
        self.rank = int(rank)
        with torch.no_grad():
            left, values, right = torch.linalg.svd(original.weight.detach(), full_matrices=False)
            root = values[:rank].sqrt()
            self.U = nn.Parameter((left[:, :rank] * root.unsqueeze(0)).clone())
            self.V = nn.Parameter((root.unsqueeze(1) * right[:rank]).clone())
            self.bias = nn.Parameter(original.bias.detach().clone()) if original.bias is not None else None

    def forward(self, x):
        return F.linear(F.linear(x, self.V), self.U, self.bias)

    def merged_weight(self):
        return self.U @ self.V

    def merged_linear(self):
        """Create a standalone dense inference layer without moving RNG streams."""
        # Model construction is CPU float32 under this protocol.  fork_rng also
        # keeps this utility nonintrusive if used for CUDA diagnostic models.
        devices = [self.U.device.index] if self.U.is_cuda else []
        with torch.random.fork_rng(devices=devices):
            layer = nn.Linear(self.in_features, self.out_features, bias=self.bias is not None)
        layer = layer.to(device=self.U.device, dtype=self.U.dtype)
        with torch.no_grad():
            layer.weight.copy_(self.merged_weight())
            if self.bias is not None:
                layer.bias.copy_(self.bias)
        return layer


class Model(BiasConditionModel):
    """Exactly the existing P3 network except registered B dropout/F rank."""

    def __init__(self, raw_dim, cond, cfg, recipe):
        super().__init__(raw_dim, cond, cfg, 'P3')
        self.recipe = dict(recipe)
        if recipe['level_dropout'] is not None:
            for module in self.level.modules():
                if isinstance(module, nn.Dropout):
                    module.p = float(recipe['level_dropout'])
        if recipe['level_rank'] is not None:
            self.level.net[0] = LowRankLinear(self.level.net[0], recipe['level_rank'])

    def forward_level(self, x):
        z = self.level.net[:-1](x)
        gamma, beta = self.condition(x[:, self.cond_idx]).chunk(2, dim=-1)
        z = (1 + self.scale * torch.tanh(gamma)) * z + self.scale * torch.tanh(beta)
        return self.level.net[-1](z)

    def forward(self, x):
        return self.forward_level(x), self.shape(x[:, :self.raw_dim])


def parameter_groups(model):
    """Return (Level including FiLM, Shape), mutually exclusive and complete."""
    named = [(name, param) for name, param in model.named_parameters() if param.requires_grad]
    level = [param for name, param in named if not name.startswith('shape.')]
    shape = [param for name, param in named if name.startswith('shape.')]
    level_ids, shape_ids = set(map(id, level)), set(map(id, shape))
    if not level_ids.isdisjoint(shape_ids):
        raise AssertionError('Parameter groups overlap')
    if level_ids | shape_ids != {id(param) for param in model.parameters() if param.requires_grad}:
        raise AssertionError('Parameter grouping misses trainable parameters')
    if not {id(param) for param in model.condition.parameters() if param.requires_grad} <= level_ids:
        raise AssertionError('FiLM must be in the Level group')
    return level, shape


def make_optimizer(model, cfg, recipe):
    """Preserve original single-group AdamW unless B3/B4/B5 requires a split."""
    parameter_groups(model)
    if not recipe['split_optimizer']:
        return torch.optim.AdamW(model.parameters(), lr=cfg['lr'], weight_decay=cfg['weight_decay'])
    # Per-parameter groups preserve the *global* original named_parameters order,
    # including condition after Shape; collecting two big groups would reorder it.
    groups = []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        branch = 'shape' if name.startswith('shape.') else 'level'
        lr = cfg['lr'] * (recipe['level_lr_multiplier'] if branch == 'level' else 1.0)
        wd = cfg['weight_decay']
        if branch == 'level' and recipe['level_weight_decay'] is not None:
            wd = recipe['level_weight_decay']
        groups.append({'params': [parameter], 'lr': lr, 'weight_decay': wd,
                       'branch': branch, 'parameter_name': name})
    return torch.optim.AdamW(groups, lr=cfg['lr'], weight_decay=cfg['weight_decay'])


def set_learning_rate(opt, cfg, recipe, epoch):
    if int(epoch) != epoch or not 1 <= epoch <= recipe['epochs']:
        raise ValueError('Invalid one-based learning-rate epoch')
    base_lr = float(cfg['lr'])
    if recipe['lr_schedule'] == 'cosine':
        base_lr = recipe['minimum_lr'] + (base_lr - recipe['minimum_lr']) * (
            1 + math.cos(math.pi * (epoch - 1) / (recipe['epochs'] - 1))) / 2
    elif recipe['lr_schedule'] != 'constant':
        raise ValueError('Unknown learning-rate schedule')
    for group in opt.param_groups:
        multiplier = recipe['level_lr_multiplier'] if group.get('branch') == 'level' else 1.0
        group['lr'] = base_lr * multiplier
    return {'base_lr': base_lr, 'level_lr': base_lr * recipe['level_lr_multiplier'],
            'shape_lr': base_lr}


def _tail_calendar(issue):
    """Calendar information from actual quarter-hour tail timestamps, no labels."""
    start = issue + np.timedelta64(64 * 15, 'm')
    end = start + np.timedelta64(95 * 15, 'm')
    midpoint = issue.astype('datetime64[s]') + np.timedelta64(100350, 's')
    years = midpoint.astype('datetime64[Y]').astype(np.int64) + 1970
    first_month = start.astype('datetime64[M]')
    last_month = end.astype('datetime64[M]')
    boundary = (first_month + np.timedelta64(1, 'M')).astype('datetime64[m]')
    # At most one month boundary in a tail.  Each row starts at an exact hour.
    first_fraction = np.minimum(96, (boundary - start).astype('timedelta64[m]').astype(np.int64) // 15) / 96
    month_first = first_month.astype(np.int64) % 12 + 1
    month_last = last_month.astype(np.int64) % 12 + 1
    season = first_fraction * (month_first <= 4) + (1 - first_fraction) * (month_last <= 4)
    return years, month_first, month_last, first_fraction, season


def _fraction(value, n, name):
    result = np.asarray(value, dtype=np.float64)
    if result.shape != (n,) or not np.isfinite(result).all() or np.any((result < 0) | (result > 1)):
        raise ValueError(name + ' must be a finite per-row fraction in [0,1]')
    return result


def weights(issue, cutoff, recipe, epoch, season_fraction=None, spring_fraction=None, target_year=None):
    """Return float32 Level/Shape weights and label-free distribution audits.

    ``target_year`` is a per-row tail-midpoint year vector, not the query year.
    Passing None derives it from issue. ``spring_fraction`` uses the unchanged
    official calendar's union pre_14/spring_holiday/return_1_3/return_4_14.
    Neither normalization arrays nor targets are accepted by this function.
    """
    issue = np.asarray(issue, dtype='datetime64[m]')
    if issue.ndim != 1 or len(issue) == 0 or np.isnat(issue).any():
        raise ValueError('Nonempty finite hourly issue vector required')
    minute = issue.astype(np.int64) % 1440
    if np.any(minute % 60):
        raise ValueError('Only hourly fit origins are supported')
    is08 = minute == 480
    n, n08 = len(issue), int(is08.sum())
    if not 0 < n08 < n:
        raise ValueError('Both clock strata must exist')
    cutoff = np.datetime64(cutoff, 'm')
    if np.isnat(cutoff) or np.any(issue > cutoff):
        raise ValueError('Age requires fit issues no later than the fold cutoff')
    years, month_first, month_last, first_fraction, computed_season = _tail_calendar(issue)
    if target_year is not None:
        supplied_year = np.asarray(target_year)
        if supplied_year.shape != (n,) or not np.array_equal(supplied_year, years):
            raise ValueError('target_year must equal each actual tail midpoint year')
    season = computed_season if season_fraction is None else _fraction(season_fraction, n, 'season_fraction')
    if not np.allclose(season, computed_season, rtol=0, atol=1e-7):
        raise ValueError('Season fractions must use actual tail96 point timestamps')
    spring = None if spring_fraction is None else _fraction(spring_fraction, n, 'spring_fraction')
    mass_l, mass_s = clock_masses(recipe, epoch, n08 / n)
    raw = np.ones(n, dtype=np.float64)
    distribution = recipe['level_distribution']
    if distribution == 'season':
        raw += season
    elif distribution == 'year_equal':
        for mask in (is08, ~is08):
            unique, count = np.unique(years[mask], return_counts=True)
            for year, frequency in zip(unique, count):
                raw[mask & (years == year)] = 1.0 / frequency
    elif distribution == 'recency':
        age = (cutoff - issue).astype('timedelta64[m]').astype(np.float64) / 1440
        raw = 0.5 + 0.5 * np.exp2(-age / recipe['recency_half_life_days'])
    elif distribution == 'spring':
        if spring is None:
            raise ValueError('Spring weighting requires actual old-calendar tail fractions')
        raw += recipe['spring_coefficient'] * spring
    elif distribution != 'uniform':
        raise ValueError('Unknown Level training distribution')

    def population_weights(mass, multipliers):
        result = np.ones(n, dtype=np.float32)
        for mask, group_mass in ((is08, mass), (~is08, 1 - mass)):
            if distribution == 'uniform' or multipliers is None:
                # Match the V9 scalar expression and float32 assignment exactly.
                result[mask] = group_mass * n / int(mask.sum())
            else:
                result[mask] = n * group_mass * multipliers[mask] / multipliers[mask].sum(dtype=np.float64)
        return result

    population_l = population_weights(mass_l, raw)
    population_s = population_weights(mass_s, None)
    w, ws = population_l.copy(), population_s.copy()
    sampler = recipe['sampler']
    if sampler == 'stratified':
        if distribution != 'uniform':
            raise ValueError('A1 plus D is not a registered combination')
        quota08 = recipe['stratified_batch08']
        quota_other = recipe['stratified_batch_other']
        proposal08 = quota08 / (quota08 + quota_other)
        w[is08], w[~is08] = mass_l / proposal08, (1 - mass_l) / (1 - proposal08)
        ws[is08], ws[~is08] = mass_s / proposal08, (1 - mass_s) / (1 - proposal08)
    elif sampler != 'uniform':
        raise ValueError('Unknown sampler')

    def audit_branch(population, returned, desired):
        q = population.astype(np.float64)
        total = q.sum()
        actual = q[is08].sum() / total
        np.testing.assert_allclose(total / n, 1.0, rtol=1e-7, atol=1e-8)
        np.testing.assert_allclose(actual, desired, rtol=1e-7, atol=1e-8)
        month_mass = {}
        for month in range(1, 13):
            fraction = first_fraction * (month_first == month) + (1 - first_fraction) * (month_last == month)
            month_mass[str(month)] = float(np.dot(q, fraction) / total)
        return {
            'target_mass08': desired,
            'mass08': float(actual),
            'mass_other': float(1 - actual),
            'population_mean_weight': float(total / n),
            'population_max_weight': float(q.max()),
            'returned_min_weight': float(returned.min()),
            'returned_max_weight': float(returned.max()),
            'returned_fit_mean_weight': float(returned.mean(dtype=np.float64)),
            'kish_weight_ess_not_independent_samples': float(total ** 2 / np.square(q).sum()),
            'year_mass': {str(year): float(q[years == year].sum() / total) for year in np.unique(years)},
            'clock_hour_mass': {str(hour): float(q[minute == hour * 60].sum() / total) for hour in np.unique(minute // 60)},
            'tail_point_month_mass': month_mass,
            'tail_point_spring_phase_union_mass': None if spring is None else float(np.dot(q, spring) / total),
            'tail_point_non_spring_phase_mass': None if spring is None else float(np.dot(q, 1 - spring) / total),
            'year_mass_within_clock': {
                label: {str(year): float(q[mask & (years == year)].sum() / q[mask].sum())
                        for year in np.unique(years[mask])}
                for label, mask in (('08', is08), ('other', ~is08))
            },
        }

    audit = {
        'n': n, 'n08': n08, 'population_p08': n08 / n, 'epoch': int(epoch),
        'sampler': sampler, 'level_distribution': distribution,
        'normalization': 'unchanged_unweighted_fit_norm',
        'returned_weights_semantics': ('proposal_importance_for_fixed_64_192_batch_mean'
                                       if sampler == 'stratified' else 'fit_population_loss_weights'),
        'level': audit_branch(population_l, w, mass_l),
        'shape': audit_branch(population_s, ws, mass_s),
        'raw_level_multiplier_min': float(raw.min()),
        'raw_level_multiplier_max': float(raw.max()),
        'cutoff': str(cutoff),
    }
    if sampler == 'stratified':
        audit['sampling'] = {
            'batch08': quota08, 'batch_other': quota_other,
            'with_replacement': True, 'independently_uniform_within_stratum': True,
            'sample_probability08_per_draw': 1 / n08,
            'sample_probability_other_per_draw': 1 / (n - n08),
            'level_conditional_mean_coefficients': [mass_l, 1 - mass_l],
            'shape_conditional_mean_coefficients': [mass_s, 1 - mass_s],
            'population_weight_mean_one_assertion_does_not_apply_to_returned_A1_weights': True,
        }
    return w, ws, audit


def reconstruct_torch(base, level, shape):
    """Float64 differentiable transcription of the unchanged NumPy decoder."""
    b = base.to(dtype=torch.float64)
    ell = level.to(dtype=torch.float64).reshape(-1, 1).clamp(-2.0, 2.0)
    sh = shape.to(dtype=torch.float64)
    if b.ndim != 2 or b.shape[1] != 160 or sh.shape != b.shape or ell.shape[0] != b.shape[0]:
        raise ValueError('Decoder requires matching [N,160] base/shape and one Level per row')
    sh = sh - sh.mean(dim=1, keepdim=True)
    sh = sh.clamp(-2.0, 2.0)
    curve = b * sh.exp()
    return b.mean(dim=1, keepdim=True) * ell.exp() * curve / curve.mean(dim=1, keepdim=True)


def losses(pl, ps, ll, sh, w, ws, recipe, norms, b, aux_target, aux_std, second_level=None):
    """Original two losses plus an already coefficient-scaled E1 contribution.

    Inputs/targets are standardized except b and the raw log-ratio aux_target.
    For a C+E1 combination, E1 uses the first ordinary joint forward; only the
    C supervised Level term is double-forward. Inference is always unchanged.
    """
    if pl.numel() != pl.shape[0] or ll.numel() != pl.shape[0]:
        raise ValueError('Level output and target must each contain one value per row')
    w, ws = w.reshape(-1), ws.reshape(-1)
    if len(w) != pl.shape[0] or len(ws) != pl.shape[0]:
        raise ValueError('Weights must have one value per row')
    residual = (pl.reshape(-1) - ll.reshape(-1))
    per_level = residual.square()
    beta = recipe['consistency_beta']
    if beta is not None:
        if second_level is None or second_level.shape != pl.shape:
            raise ValueError('C0/C1/C2 require a second same-input Level forward')
        second = second_level.reshape(-1)
        per_level = 0.5 * (per_level + (second - ll.reshape(-1)).square())
        per_level = per_level + beta * (pl.reshape(-1) - second).square()
    elif second_level is not None:
        raise ValueError('Second Level forward is exclusive to registered C recipes')
    loss_level = (w * per_level).mean()
    shape_for_loss = ps
    if recipe['project_shape_loss']:
        raw_shape = ps * norms['shape_std'] + norms['shape_mean']
        centered_shape = raw_shape - raw_shape.mean(dim=1, keepdim=True)
        shape_for_loss = (centered_shape - norms['shape_mean']) / norms['shape_std']
    loss_shape = (ws * (shape_for_loss - sh).square().mean(dim=1)).mean()
    auxiliary = pl.new_zeros(())
    coefficient = recipe['auxiliary_tail_mean_coefficient']
    if coefficient:
        if b is None or aux_target is None or aux_std is None:
            raise ValueError('E1 requires base160 and fit-only auxiliary targets/std')
        level = pl * norms['level_std'] + norms['level_mean']
        shape = ps * norms['shape_std'] + norms['shape_mean']
        prediction = reconstruct_torch(b, level, shape)
        u_pred = (prediction[:, 64:160].mean(dim=1) / b.to(torch.float64)[:, 64:160].mean(dim=1)).log()
        target = aux_target.reshape(-1).to(dtype=u_pred.dtype, device=u_pred.device)
        standard = torch.as_tensor(aux_std, dtype=u_pred.dtype, device=u_pred.device)
        if standard.numel() != 1 or not bool(torch.isfinite(standard).all()) or not bool((standard > 0).all()):
            raise ValueError('aux_std is one positive finite unweighted-fit scale')
        if target.shape != u_pred.shape:
            raise ValueError('Auxiliary target must have one value per sample')
        auxiliary = coefficient * (w * ((u_pred - target) / standard.reshape(())).square()).mean()
    return loss_level, loss_shape, auxiliary


