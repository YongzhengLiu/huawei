from pathlib import Path
import os,json
PACKAGE=Path(__file__).resolve().parents[1]
SNAPSHOT=Path(os.environ.get('HEBEI_SNAPSHOT',str(PACKAGE/'original_snapshot'))).resolve()
BASE_PREFIX='/hpc2hdd/home/yliu704/lyz'
def remap(value):
    if isinstance(value,str) and (value==BASE_PREFIX or value.startswith(BASE_PREFIX+'/')):return str(SNAPSHOT/value[len(BASE_PREFIX):].lstrip('/'))
    if isinstance(value,dict):return {k:remap(v) for k,v in value.items()}
    if isinstance(value,list):return [remap(v) for v in value]
    return value
UP=SNAPSHOT/'hebei_phase_year_robust_v23_20260910'
CFG=remap(json.loads((UP/'config.json').read_text()))
