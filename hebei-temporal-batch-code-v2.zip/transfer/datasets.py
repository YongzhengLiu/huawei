"""Prepared-window format shared by different positive-load datasets.

Scoring truth must be kept in a different file and is never opened here.
"""
from pathlib import Path
import numpy as np
from .contracts import WindowBatch,FitBatch

class NpzWindowDataset:
    def __init__(self,fit_path,query_path):self.fit_path=Path(fit_path);self.query_path=Path(query_path)
    @staticmethod
    def _windows(z):
        return WindowBatch(issue_time=z['issue_time'],target_start_time=z['target_start_time'],past_target=z['past_target'],past_last_time=z['past_last_time'],future_known_covariates=z['future_known_covariates'] if 'future_known_covariates' in z.files else None,future_covariate_available_at=z['future_covariate_available_at'] if 'future_covariate_available_at' in z.files else None,covariate_names=tuple(z['covariate_names'].astype(str)) if 'covariate_names' in z.files else (),perfect_weather=bool(z['perfect_weather'].item()) if 'perfect_weather' in z.files else False)
    def load_fit(self):
        with np.load(self.fit_path,allow_pickle=False) as z:return FitBatch(self._windows(z),z['future_target'])
    def load_query(self):
        with np.load(self.query_path,allow_pickle=False) as z:
            assert not ({'future_target','truth','truth96','truth160','query_truth'}&set(z.files)),'Keep scoring truth separate from query inputs'
            return self._windows(z)
