"""Full original96-epoch optimization segment. Historical Slurm submission and
machine-timing audits are separate from portable quality reproduction."""
from core import *
import native,sampler

def train(seed):
    assert seed in (42,43,44)
    manifest,rt=locked()
    arm=sampler.ARM
    out=ROOT/f'results/{arm}/seed_{seed}'
    out.mkdir(parents=True,exist_ok=False)
    d=load()
    random.seed(seed)
    np.random.seed(seed)
    m = factory(d, seed)
    torch.manual_seed(seed + 2000)
    rng = np.random.default_rng(seed + 1000)
    mrng = np.random.default_rng(seed + 3000)
    xt = torch.from_numpy(d['xf'])
    lt = torch.from_numpy(d['level'])
    st = torch.from_numpy(d['shape'])
    ws = torch.from_numpy(d['wc']['shape_weights'])
    opt = torch.optim.AdamW(m.parameters(), lr=0.0001, weight_decay=0.001)
    chron = np.argsort(d['wc']['issue_time'], kind='stable')
    order_hashes = []
    rw = old.r.PhaseYearWeights(d['wc']['issue_time'], d['wc']['weights'], old.r.CFG['holiday_file'], 1.0)
    blocks = old.mask_blocks('WPAIR_DROPAB')
    summed = None
    count = 0
    steps = 0
    mask_draws = 0
    n = len(xt)
    train_start = time.perf_counter()
    recipe = old.r.resolve('D2')
    for epoch in range(1, 97):
        w = torch.from_numpy(rw.start(epoch))
        m.train()
        native_order = rng.permutation(n)
        order = sampler.order(native_order, chron)
        order_hashes.append(hashlib.sha256(order.astype('<i8').tobytes()).hexdigest())
        total = 0.0
        for left in range(0, n, 256):
            ix = order[left:left + 256]
            x = xt[ix].clone()
            take = mrng.random(len(ix)) < 0.1
            choice = mrng.integers(0, 3, size=len(ix))
            mask(x, take, choice, blocks, True)
            mask_draws += len(ix)
            opt.zero_grad(set_to_none=True)
            pl, ps = m(x)
            loss = sum(native.losses(pl, ps, lt[ix], st[ix], w[ix], ws[ix], recipe))
            rw.observe(ix, (pl.detach().reshape(-1) - lt[ix].reshape(-1)).square().numpy().astype(np.float64))
            assert torch.isfinite(loss)
            loss.backward()
            gn = torch.nn.utils.clip_grad_norm_(m.parameters(), 1.0)
            assert torch.isfinite(gn)
            opt.step()
            steps += 1
            total += float(loss.detach()) * len(ix)
        rw.finish()
        if epoch >= 65:
            state = m.state_dict()
            if summed is None:
                summed = {k: v.clone().double() if v.is_floating_point() else v.clone() for k, v in state.items()}
            else:
                for k, v in state.items():
                    if v.is_floating_point():
                        summed[k].add_(v.double())
                    else:
                        assert torch.equal(summed[k], v)
            count += 1
        row = dict(epoch=epoch, loss=total / n, elapsed_seconds=time.perf_counter() - START, optimizer_steps=steps, sampler_epochs=epoch)
        with (out / 'progress.jsonl').open('a') as f:
            f.write(json.dumps(row) + '\n')
        if epoch % 16 == 0:
            print(json.dumps(row), flush=True)
        assert time.perf_counter() - START < 570, 'Absolute bounded training guard'
    assert count == 32 and steps == 15264 and (mask_draws == 96 * n)
    state = m.state_dict()
    avg = {k: (v / 32).to(state[k].dtype) if v.is_floating_point() else v for k, v in summed.items()}
    m.load_state_dict(avg)
    train_seconds = time.perf_counter() - train_start
    export(out, m, d, seed, arm)
    elapsed=time.perf_counter()-START
    write(out/'PORTABLE_RETRAIN.json',dict(seed=seed,epochs=96,optimizer_steps=steps,averaged_epochs=list(range(65,97)),sampler_epoch_order_SHA=order_hashes,mask_draw_rows=mask_draws,fit_rows=40522,query_days=102,horizon=160,model_parameters=2509761,train_seconds=train_seconds,whole_process_seconds=elapsed,runtime=rt,querytruth_read=False,original_full_training_algorithm_AST_exact=True,machine_deployment_benchmark_remeasured=False))
    finish(out)
    return out
