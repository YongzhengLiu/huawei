from datetime import date
import numpy as np
from holidays import OfficialCalendar

class PhaseYearWeights:
    """Fit-only epoch-lagged weights, conserving phase/clock loss mass."""
    def __init__(self,issue,base,calendar,eta):
        issue=np.asarray(issue,dtype='datetime64[m]');tailmid=issue+np.timedelta64(100350,'s')
        days=tailmid.astype('datetime64[D]');cal=OfficialCalendar(calendar)
        mapping={d:cal.state(date.fromisoformat(str(d)))[2] for d in np.unique(days)}
        phase=np.array([mapping[d] for d in days]);year=days.astype('datetime64[Y]').astype(int)+1970
        clock=issue.astype(np.int64)%1440==480
        self.base=np.asarray(base,np.float64);self.eta=eta;self.phase=phase;self.groups=[];self.pools=[]
        for ph in sorted(set(phase)-{'none'}):
            for cl in (False,True):
                mask=(phase==ph)&(clock==cl);pool=[]
                for yr in np.unique(year[mask]):
                    ids=np.flatnonzero(mask&(year==yr));pool.append(len(self.groups));self.groups.append(ids)
                if pool:self.pools.append(pool)
        self.gid=np.full(len(issue),-1,int)
        for j,ids in enumerate(self.groups):self.gid[ids]=j
        self.ema=None;self.current=self.base.copy();self.history=[]
    def start(self,epoch):
        self.sums=np.zeros(len(self.groups));self.counts=np.zeros(len(self.groups));self.current=self.base.copy()
        if self.eta and epoch>16 and self.ema is not None:
            for pool in self.pools:
                risks=self.ema[pool];center=risks.mean();scale=max(center,1e-6)
                raw=np.exp(np.clip(self.eta*(risks-center)/scale,-np.log(2),np.log(2)))
                mass=np.array([self.base[self.groups[g]].sum() for g in pool]);raw/=np.dot(raw,mass)/mass.sum()
                for g,r in zip(pool,raw):self.current[self.groups[g]]*=r
        np.testing.assert_array_equal(self.current[self.phase=='none'],self.base[self.phase=='none'])
        for pool in self.pools:
            ids=np.concatenate([self.groups[g] for g in pool]);np.testing.assert_allclose(self.current[ids].sum(),self.base[ids].sum(),rtol=1e-12)
        assert np.isfinite(self.current).all() and (self.current>0).all()
        self.history.append(dict(epoch=epoch,group_multiplier=[float((self.current[g]/self.base[g]).mean()) for g in self.groups]))
        return self.current.astype(np.float32)
    def observe(self,ix,loss):
        g=self.gid[ix];valid=g>=0;self.sums+=np.bincount(g[valid],weights=loss[valid],minlength=len(self.groups));self.counts+=np.bincount(g[valid],minlength=len(self.groups))
    def finish(self):
        assert (self.counts>0).all();risk=self.sums/self.counts
        self.ema=risk if self.ema is None else .8*self.ema+.2*risk
        self.history[-1]['online_train_risk']=risk.tolist();self.history[-1]['ema_risk']=self.ema.tolist()
