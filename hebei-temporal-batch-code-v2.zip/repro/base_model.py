"""A single parallel Level/Shape corrector; FiLM is inside its Level branch."""
import torch
from torch import nn
from legacy_train import Branch


def condition_indices(dimensions, raw_dim):
    selected=[]; offset=0
    for name, width in dimensions.items():
        if any(word in name for word in ('weather','province','dispersion','calendar','h3_','causal_event')):
            selected.extend(range(offset, offset+width))
        offset += width
    assert offset == raw_dim
    return selected + list(range(raw_dim, raw_dim+12))


class BiasConditionModel(nn.Module):
    def __init__(self, raw_dim, cond_idx, config, variant):
        super().__init__()
        self.raw_dim=raw_dim; self.variant=variant
        self.scale=config['condition_scale']
        self.register_buffer('cond_idx', torch.tensor(cond_idx, dtype=torch.long))
        torch.manual_seed(config['seed'])
        d=raw_dim+12
        widths=list(config['level_hidden'])
        # Match P2 total parameter count to P3 within one first-layer unit.
        extra=(len(cond_idx)+1)*config['condition_hidden']+(config['condition_hidden']+1)*128
        unit=d+1+2+widths[1]
        if variant=='P2': widths[0] += round(extra/unit)
        self.level=Branch(d,widths,1,config['dropout'])
        if variant in ('P1','P3'):
            # Preserve the random P0 function exactly before training. New
            # state columns start at zero; this is NOT a trained checkpoint.
            torch.manual_seed(config['seed'])
            reference=Branch(raw_dim,config['level_hidden'],1,config['dropout'])
            copied=reference.state_dict()
            first=torch.zeros_like(self.level.net[0].weight)
            first[:,:raw_dim]=copied['net.0.weight']
            copied['net.0.weight']=first
            self.level.load_state_dict(copied)
        torch.manual_seed(config['seed']+1)
        self.shape=Branch(raw_dim,config['shape_hidden'],160,config['dropout'])
        if variant=='P3':
            torch.manual_seed(config['seed']+2)
            self.condition=nn.Sequential(nn.Linear(len(cond_idx),config['condition_hidden']),nn.GELU(),
                nn.Linear(config['condition_hidden'],128))
            nn.init.zeros_(self.condition[-1].weight)
            nn.init.zeros_(self.condition[-1].bias)
        self.widths=widths

    def forward(self,x):
        if self.variant=='P3':
            z=self.level.net[:-1](x)
            gamma,beta=self.condition(x[:,self.cond_idx]).chunk(2,dim=-1)
            z=(1+self.scale*torch.tanh(gamma))*z+self.scale*torch.tanh(beta)
            level=self.level.net[-1](z)
        else:
            level=self.level(x)
        return level,self.shape(x[:,:self.raw_dim])


