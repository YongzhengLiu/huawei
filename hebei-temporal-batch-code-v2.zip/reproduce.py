#!/usr/bin/env python3
"""Portable full-data training and checkpoint/metric reproduction."""
from pathlib import Path
import argparse,json,os,sys,csv
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repro'))
os.environ.setdefault('PYTHONDONTWRITEBYTECODE','1')
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ.setdefault(name,'8')
os.environ['CUDA_VISIBLE_DEVICES']=''
ARM='TEMPORAL_STRATIFIED_BATCH'
EXPECTED={42:97.70614386020668}

def score_after_full_network(folder,reference):
    import numpy as np
    from verify_network import verify
    # This performs the complete Level/Shape/FiLM network and full160 decoder
    # independently in NumPy, checking every saved array and date, before truth.
    network=verify(folder)
    assert network['all102x160_verified'] and not network['query_truth_opened']
    with np.load(folder/'issued.npz',allow_pickle=False) as z:
        prediction=z['prediction160'].astype(np.float64)
        dates=z['target_start_time'].astype('datetime64[D]');issues=z['issue_time']
    with np.load(reference,allow_pickle=False) as z:
        np.testing.assert_array_equal(z['issue_time'],issues)
        np.testing.assert_array_equal(z['target_start_time'].astype('datetime64[D]'),dates)
        truth=z['truth96'].astype(np.float64);control=z['prediction96'].astype(np.float64)
    np.testing.assert_array_equal(dates,np.arange(np.datetime64('2026-01-01'),np.datetime64('2026-04-13')))
    daily=100.-100.*np.sqrt(np.sum(((prediction[:,64:160]-truth)/truth)**2,axis=1)/96.)
    baseline=100.-100.*np.sqrt(np.sum(((control-truth)/truth)**2,axis=1)/96.)
    return dict(KPIE=float(daily.mean()),baseline_KPIE=float(baseline.mean()),gain_pp=float((daily-baseline).mean()),block_KPIE=[float(daily[i:i+34].mean()) for i in (0,34,68)],days=102,horizon=160,scored_slice=[64,160],network=network,truth_opened_after_full_network=True),dates,daily,baseline

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('mode',choices=['verify','replay','train','score']);ap.add_argument('--seed',type=int,default=42,choices=[42,43,44]);ap.add_argument('--snapshot',type=Path);ap.add_argument('--output',type=Path);ap.add_argument('--folder',type=Path);ap.add_argument('--reference',type=Path);ap.add_argument('--skip-full-payload-hash',action='store_true',help='Only for inspecting an already fully verified bundle; not permitted by train mode.')
    a=ap.parse_args()
    if a.snapshot:os.environ['HEBEI_SNAPSHOT']=str(a.snapshot.resolve())
    from paths import SNAPSHOT
    from integrity import verify_payload
    if a.mode=='verify':print(json.dumps(verify_payload(),indent=2));return
    if a.mode=='train':
        assert not a.skip_full_payload_hash,'Full SHA checking is mandatory for retraining'
        assert a.output is not None,'--output must name a fresh run directory'
        out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);os.environ['HEBEI_OUTPUT']=str(out)
        from train_portable import train
        folder=train(a.seed)
    elif a.mode=='score':
        assert a.folder is not None,'--folder must name a completed exported model directory'
        folder=a.folder.resolve()
        if not a.skip_full_payload_hash:verify_payload()
    else:
        if not a.skip_full_payload_hash:verify_payload()
        folder=SNAPSHOT/f'hebei_day_ahead_fm_20261021/wpair_temporal_batch_20261029/results/{ARM}/seed_{a.seed}'
    ref=a.reference or SNAPSHOT/f'hebei_day_ahead_fm_20261021/grad10_test_20261022_r2/data/reference/WPAIR/seed_{a.seed}.npz'
    report,dates,daily,baseline=score_after_full_network(folder,ref)
    report.update(seed=a.seed,mode=a.mode,one_model_not_prediction_ensemble=True,window_used_for_configuration_selection=True)
    if a.mode=='replay' and a.seed in EXPECTED:
        assert abs(report['KPIE']-EXPECTED[a.seed])<=1e-10
        report['recorded_KPIE']=EXPECTED[a.seed];report['recorded_metric_reproduced']=True
    encoded=json.dumps(report,indent=2,allow_nan=False,default=lambda v:v.item())+'\n'
    if a.output is not None:
        dest=a.output.resolve();dest.mkdir(parents=True,exist_ok=True)
        (dest/'REPRODUCTION_RESULT.json').open('x').write(encoded)
        with (dest/'DAILY_KPIE.csv').open('x',newline='') as f:
            w=csv.writer(f);w.writerow(['date','candidate_KPIE','control_KPIE','gain_pp'])
            for date,c,b in zip(dates,daily,baseline):w.writerow([str(date),float(c),float(b),float(c-b)])
    print(encoded,end='')

if __name__=='__main__':main()
